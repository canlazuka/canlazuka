import urllib,urllib2,re,xbmcplugin,xbmcgui
USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:36.0) Gecko/20100101 Firefox/36.0'
#TV DASH - by You 2008.
from cookielib import CookieJar
cj = CookieJar()
import json as api
try:
    import urllib.parse as compat_urllib_parse
except ImportError:  # Python 2
    import urllib as compat_urllib_parse
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
pluginhandle = int(sys.argv[1])
def CATEGORIES(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        magic = api.loads(link, encoding='latin1')
        addDir("Startseite",url,1,'','Folder','')
        for i in magic['tags']['popular']:
            addDir(i,'http://beeg.com/api/v5/index/tag/0/pc?tag='+i,1,'','Folder',i)
        xbmc.executebuiltin("Container.SetViewMode(400)")
        
def SEARCH(url):
        kb = xbmc.Keyboard('', 'Search beeg', False)
        kb.doModal()
        search = kb.getText()
        search=search.decode('utf-8').encode('iso-8859-1')
        search=urllib.quote(search)
        url_search = 'http://beeg.com/search?q='+search
        INDEX(url_search)
        
def INDEX(url,id):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        magic = api.loads(link, encoding='latin1')
        for i in magic['videos']:
            addDir(i['title'].encode('utf-8'),'http://beeg.com/api/v5/video/'+i['id'],2,'http://img.beeg.com/236x177/'+i['id']+'.jpg','Video',i['id'])
            
        #-----Pagination------#
        
        pages=int(magic['pages'])
        try:
            pa=re.search("http://beeg.com/api/v5/index/main/(.*?)/pc",url).group(1)
        except:
            pass
        try:
            pa=re.search("http://beeg.com/api/v5/index/tag/(.*?)/pc\?tag=.*?",url).group(1)
        except:
            pass
        if "main" in url and (int(pa)==0 or int(pa)<pages):
            addDir("Next page--->","http://beeg.com/api/v5/index/main/"+str(int(pa)+1)+"/pc",1,'','Folder','')
        if "main" in url and int(pa)!=0:
            addDir("<---Previous page","http://beeg.com/api/v5/index/main/"+str(int(pa)-1)+"/pc",1,'','Folder','')
        if "tag=" in url and (int(pa)==0 or int(pa)<pages):
            addDir("Next page--->","http://beeg.com/api/v5/index/tag/"+str(int(pa)+1)+"/pc?tag="+id,1,'','Folder',id)
        if "tag=" in url and int(pa)!=0:
            addDir("<---Previous page","http://beeg.com/api/v5/index/tag/"+str(int(pa)-1)+"/pc?tag="+id,1,'','Folder',id)
        xbmc.executebuiltin("Container.SetViewMode(400)")

def VIDEOLINKS(url,name,img,id):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        magic = api.loads(link, encoding='latin1')
        liste=[]
        v_liste=[]
        dialog = xbmcgui.Dialog()
        try:
            v_720=magic['720p']
            enc_key = re.search("/key=(.*?)%2Cend=", v_720).group(1)
            key = decrypt_key(enc_key)
            v_720 = v_720.replace(enc_key,key)
            liste.append("720p")
            v_liste.append(v_720.replace('{DATA_MARKERS}','data=pc_DE').replace('//','https://'))
        except:
            pass
        try:
            v_480=magic['480p']
            enc_key = re.search("/key=(.*?)%2Cend=", v_480).group(1)
            key = decrypt_key(enc_key)
            v_480 = v_480.replace(enc_key,key)
            liste.append("480p")
            v_liste.append(v_480.replace('{DATA_MARKERS}','data=pc.DE').replace('//','https://'))
        except:
            pass
        try:
            v_240=magic['240p']
            enc_key = re.search("/key=(.*?)%2Cend=", v_240).group(1)
            key = decrypt_key(enc_key)
            v_240 = v_240.replace(enc_key,key)
            liste.append("240p")
            v_liste.append(v_240.replace('{DATA_MARKERS}','data=pc.DE').replace('//','https://'))
        except:
            pass
        quality = dialog.select('Quality',liste)
        if quality == 0:
            play_vid(name,v_liste[0],img)
        elif quality == 1:
            play_vid(name,v_liste[1],img)
        elif quality == 2:
            play_vid(name,v_liste[2],img)
        else:
            pass
    
def decrypt_key(key):
        compat_chr = chr
        # Reverse engineered from http://static.beeg.com/cpl/1105.js
        a = '5ShMcIQlssOd7zChAIOlmeTZDaUxULbJRnywYaiB'
        e = compat_urllib_parse_unquote(key)
        o = ''.join([
            compat_chr(compat_ord(e[n]) - compat_ord(a[n % len(a)]) % 21)
            for n in range(len(e))])
        return ''.join(split(o, 3)[::-1])

def compat_ord(c):
    if type(c) is int:
        return c
    else:
        return ord(c)

def split(o, e):
        def cut(s, x):
            n.append(s[:x])
            return s[x:]
        n = []
        r = len(o) % e
        if r > 0:
            o = cut(o, r)
        while len(o) > e:
            o = cut(o, e)
        n.append(o)
        return n
        
def compat_urllib_parse_unquote_to_bytes(string):
        """unquote_to_bytes('abc%20def') -> b'abc def'."""
        # Note: strings are encoded as UTF-8. This is only an issue if it contains
        # unescaped non-ASCII characters, which URIs should not.
        compat_str = unicode
        if not string:
            # Is it a string-like object?
            string.split
            return b''
        if isinstance(string, compat_str):
            string = string.encode('utf-8')
        bits = string.split(b'%')
        if len(bits) == 1:
            return string
        res = [bits[0]]
        append = res.append
        for item in bits[1:]:
            try:
                append(compat_urllib_parse._hextochr[item[:2]])
                append(item[2:])
            except KeyError:
                append(b'%')
                append(item)
        return b''.join(res)

def compat_urllib_parse_unquote(string, encoding='utf-8', errors='replace'):
        """Replace %xx escapes by their single-character equivalent. The optional
        encoding and errors parameters specify how to decode percent-encoded
        sequences into Unicode characters, as accepted by the bytes.decode()
        method.
        By default, percent-encoded sequences are decoded with UTF-8, and invalid
        sequences are replaced by a placeholder character.
        unquote('abc%20def') -> 'abc def'.
        """
        _asciire = (compat_urllib_parse._asciire if hasattr(compat_urllib_parse, '_asciire')
                else re.compile('([\x00-\x7f]+)'))
        if '%' not in string:
            string.split
            return string
        if encoding is None:
            encoding = 'utf-8'
        if errors is None:
            errors = 'replace'
        bits = _asciire.split(string)
        res = [bits[0]]
        append = res.append
        for i in range(1, len(bits), 2):
            append(compat_urllib_parse_unquote_to_bytes(bits[i]).decode(encoding, errors))
            append(bits[i + 1])
        return ''.join(res)
        
def play_vid(name,url,img):
        listitem = xbmcgui.ListItem(name,thumbnailImage=img)
        listitem.setProperty('mimetype', 'video/x-msvideo')
        listitem.setProperty('IsPlayable', 'true')
        listitem = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name,url,mode,iconimage,status,id):
        u = build_url({'mode': mode, 'name': name.encode('utf-8'), 'url': url, 'img': iconimage, 'id': id})
        if status=='Folder':
            ok=True
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name } )
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
            return ok
        else:
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name } )
            liz.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=liz)
        

def build_url(query):
        return sys.argv[0] + '?' + urllib.urlencode(query)

params=get_params()
url=None
name=None
mode=None
img=None
id=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        id=str(params["id"])
except:
        pass
        
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://beeg.com/api/v5/index/main/0/pc')
       
elif mode==1:
        print ""+url
        INDEX(url,id)
        
elif mode==2:
        print ""+url
        VIDEOLINKS(url,name,img,id)

elif mode==3:
        print ""+url
        SEARCH(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
