#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import urllib,re,os
import xbmcplugin,xbmcgui
import xbmcaddon,xbmc
import xbmcvfs
import simple_requests as requests
import urlparse
import base64

addon = xbmcaddon.Addon(id='plugin.video.seriesnever')
home = addon.getAddonInfo('path').decode('utf-8')
image = xbmc.translatePath(os.path.join(home, 'icon.png'))
base_url = 'http://seriesever.net/'
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1)'}

datapath = xbmc.translatePath('special://profile/addon_data/plugin.video.seriesnever/')
if not os.path.isdir(datapath):
    os.mkdir(datapath)

pluginhandle = int(sys.argv[1])

def list_categories():
    addDir('Neue Episoden',base_url,'list_new',image)
    addDir('Alle Serien',base_url+'andere-serien.html','list_series',image)
    addDir('Filme',base_url+'filme.html','list_series',image)
    addDir('Anime',base_url+'anime-serien.html','list_series',image)
    genres = get_genres()
    for genre in genres:
        url = genre['url']
        name = genre['genre']
        addDir(name,url,'list_series',image)
    xbmcplugin.endOfDirectory(pluginhandle)
    
def list_new():
    url = args['url'][0]
    content = requests.get(url, headers=headers).text
    episodes = re.findall('<div class="box-container">(.*?)</div>', content, re.DOTALL)
    for episode in episodes:
        match = re.findall('<a href="(.*?)" class="play" title="(.*?)">.*?</ul>.*?src="(.*?)"', episode, re.DOTALL)
        for url, name, cover in match:
            addLink(name,url,'play',cover)
    xbmcplugin.endOfDirectory(pluginhandle)

def get_genres():
    # _genres = []
    # try:
        # content = requests.get(base_url, headers=headers).text
        # match = re.findall('</span> Genre</h3>(.*?)<div class="main-content row">', content, re.DOTALL)
        # genres = re.findall('<li><a href="(.*?)" title="(.*?)">', match[0])
        # for url, genre in genres:
            # _genres.append({'url': url, 'genre': genre})
    # except:
        # pass
    _genres = ({'url': '%sgenre/abenteuer.html' % base_url, 'genre': 'Abenteuer '}, {'url': '%sgenre/action.html' % base_url, 'genre': 'Action '}, {'url': '%sgenre/animation.html % base_url', 'genre': 'Animation '}, {'url': '%sgenre/arzt.html' % base_url, 'genre': 'Arzt '}, {'url': '%sgenre/biografie.html' % base_url, 'genre': 'Biografie '}, {'url': '%sgenre/doku.html' % base_url, 'genre': 'Dokumentation '}, {'url': '%sgenre/drama.html' % base_url, 'genre': 'Drama '}, {'url': '%sgenre/familie.html' % base_url, 'genre': 'Familie '}, {'url': '%sgenre/fantasy.html' % base_url, 'genre': 'Fantasy '}, {'url': '%sgenre/gericht.html' % base_url, 'genre': 'Gericht '}, {'url': '%sgenre/historie.html % base_url', 'genre': 'Historie '}, {'url': '%sgenre/horror.html' % base_url, 'genre': 'Horror '}, {'url': '%sgenre/komoedie.html' % base_url, 'genre': 'Kom\xc3\xb6die '}, {'url': '%sgenre/krieg.html' % base_url, 'genre': 'Krieg '}, {'url': '%sgenre/krimi.html' % base_url, 'genre': 'Krimi '}, {'url': '%sgenre/musik.html' % base_url, 'genre': 'Musik '}, {'url': '%sgenre/romanze.html' % base_url, 'genre': 'Romanze '}, {'url': '%sgenre/sci-fi.html' % base_url, 'genre': 'Sci-Fi '}, {'url': '%sgenre/soap.html' % base_url, 'genre': 'Soap '}, {'url': '%sgenre/thriller.html' % base_url, 'genre': 'Thriller '}, {'url': '%sgenre/western.html' % base_url, 'genre': 'Western '})
    return _genres

def list_series():
    url = args['url'][0]
    series_list = get_series_list(url)
    for serie in series_list:
        url = serie['url']
        name = serie['name']
        image = serie['image']
        cm = []
        library_uri = build_url({'name': name, 'url': url, 'mode': 'add_to_library'})
        cm.append( ('Add To Library', "XBMC.RunPlugin(%s)" % library_uri) )
        addDir(name,url,'list_staffeln',image,cm)
    xbmcplugin.endOfDirectory(pluginhandle)

def get_series_list(url):
    series_list = []
    try:
        content = requests.get(url, headers=headers).text
        pagination = re.findall('<ul class="pagination">(.*?)</ul>', content, re.DOTALL)[0]
        last_page = re.findall('<a href="(.*?)">', pagination)[-1]
        pages = re.findall('/(\d+).html', last_page)[0]
    except:
        pages = '1'
    for i in range(1, int(pages)+1):
        get_series(url, i, series_list)
    return series_list

def get_series(url, i, series_list):
    url = url.replace('.html','/%s.html' % i)
    content = requests.get(url, headers=headers).text
    series = re.findall('<div class="box-container">.*?<a href="(.*?)".*?src="(.*?)".*?alt="(.*?)"', content, re.DOTALL)
    for url, image, name in series:
        series_list.append({'url': url, 'name': name, 'image': image})
    return series_list

def list_staffeln():
    url = args['url'][0]
    cover = args['iconimage'][0]
    staffeln = get_staffeln(url)
    for staffel in staffeln:
        season = staffel['staffel']
        url = staffel['url']
        addDir('Staffel '+season,url,'list_episoden',cover)
    xbmcplugin.endOfDirectory(pluginhandle)
        
def get_staffeln(url):
    staffeln = []
    content = requests.get(url, headers=headers).text
    match = re.findall('<div class="panel panel-default seasons">(.*?)</div>', content, re.DOTALL)
    seasons = re.findall('<li><a href="(.*?)".*?>(.*?)</a></li>', match[0], re.DOTALL)
    for link, season in seasons:
        staffeln.append({'staffel': season, 'url': url+link})
    return staffeln

def list_episoden():
    url = args['url'][0]
    episoden = get_episoden(url)
    for episode in episoden:
        name = episode['name']
        url = episode['url']
        addLink(name,url,'play','')
    xbmcplugin.endOfDirectory(pluginhandle)
    
def get_episoden(url):
    episoden = []
    season_id = url.split('#')[-1]
    content = requests.get(url, headers=headers).text
    match = re.findall('<div id="'+season_id+'"(.*?)</div>', content, re.DOTALL)
    episodes = re.findall('<li class="list-group-item"(.*?)</li>', match[0], re.DOTALL)
    for episode in episodes:
        try: name_part1 = re.findall('<span itemprop="name">.*?(Episode.+?)</span>', episode, re.DOTALL)[0]
        except: name_part1 = ''
        try: name_part2 = re.findall('itemprop="alternateName">(.+?)</a>', episode, re.DOTALL)[0]
        except: name_part2 = ''
        name = name_part1+' - '+name_part2
        url = re.findall('<a class="episode-name" href="(.+?)"', episode, re.DOTALL)
        if url:
            episoden.append({'name': name, 'url': url[0]})
    return episoden

def play():
    url = args['url'][0]
    hoster_list = get_hoster_list(url)
    file = get_file(hoster_list)
    if file:
        listitem = xbmcgui.ListItem(path=file)
        try:
            subtitle = addon.getSetting('subtitle')
            if subtitle:
                listitem.setSubtitles([subtitle])
        except:
            xbmc.executebuiltin('Notification(Kodi Required For Subtitles,)')
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
    else:
        xbmc.executebuiltin('Notification(No Stream Found,)')
    
def get_hoster_list(url):
    hoster_list = []
    headers = {'User-Agent':'stagefright'}
    try:
        addon.setSetting('subtitle', '')
        content = requests.get(url, headers=headers).text
        video_id = re.findall('var video_id.*?(\d+)', content)[0]
        part_name = '720p'
        parts = re.findall('class="changePart" data-part="(.*?)">', content)
        if len(parts) == 1:
            part_name = parts[0]
        data = {'video_id': video_id, 'part_name': part_name, 'page': '0'}
        app = re.findall('<script src="(%sassets/js/app.js.*?)"></script>' % base_url, content)
    
        vkpass_token = None
        try:
            vkpass_token = re.findall('http://vkpass.com/configure/(.*?).js', content)[0]
        except:
            pass
    
        domain_list = []
        try: 
            domain_list = get_domain_list(app,domain_list)
        except: 
            pass
        if not domain_list: 
            domain_list = ['se1.seriesever.net','se2.seriesever.net']
        import random
        random.shuffle(domain_list)
    
        headers = {'User-Agent':'stagefright','X-Requested-With':'XMLHttpRequest', 'Host':base_url.replace('http://','www.').strip('/')}
        json_data = requests.post('%sservice/get_video_part' % base_url, headers=headers, data=data).json()
        try: part_count = json_data['part_count']
        except: part_count = 0
        for i in range(0,part_count):
            code = None
            page = str(i)
            # print "PAGE   : "+page
            data['page'] = page
            json_data = requests.post('%sservice/get_video_part' % base_url, headers=headers, data=data).json()
            try: code = json_data['url']
            except: pass
            try: 
                part = json_data['part']
                code = part[-1]
            except: pass
            try: code = json_data['part']['code']
            except: pass
            code1 = code
            code = code.replace("!BeF", "R")
            # print "CODE64-1: "+code
            code = base64.b64decode(code)
            # print "CODE-entschlüsselt: "+code
            if code:
                if 'src=' in code:
                    hoster = re.findall('src="(http.*?)"', code1)[0]
                    subtitle = re.findall('file="(http.*?srt)"', code1)
                    if subtitle:
                        addon.setSetting('subtitle', subtitle[0])
                    if vkpass_token:
                        hoster = '%s&vkpass_token=%s' % (hoster,vkpass_token)
                elif 'ok.ru' in code:
                    try:
                        code = re.search("http://ok.ru/videoembed/(\d+$)", code).group(1)
                    except:
                        pass
                    try:
                        code = re.search("http://ok.ru/video/(\d+$)", code).group(1)
                    except:
                        pass
                    try:
                        code = re.search("http://www.ok.ru/videoembed/(\d+$)", code).group(1)
                    except:
                        pass
                    # print "BURASIII  : "+code
                    link = "http://ok.ru/dk?cmd=videoPlayerMetadata&mid="+code
                    hoster = link
                else:
                    hoster = code
                hoster_list.append(hoster)
        random.shuffle(hoster_list)
    except Exception, e:
        print e
    return hoster_list
        
def get_file(hoster_list):
    # print "get_file: "+str(hoster_list)
    file = None
    for hoster in hoster_list:
        if 'picasaweb' in hoster:
            print "picasaweb   : "+str(hoster_list)
            try:
                hoster = picasaweb(hoster)
            except:
                pass
        if 'uptostream' in str(hoster):
            print "uptostream   : "+str(hoster)
            try:
                file = uptostream(hoster)
                break
            except:
                pass
        if 'vk.com' in hoster:
            print "VK   : "+str(hoster_list)
            try:
                file = vk(hoster)
                break
            except:
                pass
        if 'ok.ru' in hoster:
            print "OK.RU   : "+str(hoster_list)
            try:
                file = ok_ru(hoster)
                break
            except:
                pass
        try:
            print "stream2k   : "+str(hoster_list)
            file = stream2k(hoster)
            break
        except:
            pass
        try:
            json_data = requests.get(hoster, headers=headers).json()
            file = json_data['video_url'][-1]
            break
        except:
            pass
    return file
        
def stream2k(url):
    # print "ADRESS-1   : "+url
    url = re.search('src="(.*?)"',url).group(1)
    headers = {'User-Agent':'stagefright','referer':base_url}
    url = requests.get(url, headers=headers).text
    url = re.search('src="(.*?)"',url).group(1)
    content = requests.get(url, headers=headers).text
    link = re.search('link:"(.*?)"',content).group(1)
    link = link.replace("!BeF", "R")
    # print "CODE64-2: "+link
    link = base64.b64decode(link)
    # print "LINK   : "+link
    if 'ok.ru' in link:
        code = re.search("http://ok.ru/video/(\d+$)", urllib.unquote_plus(link))
        url = {"http://ok.ru/dk?cmd=videoPlayerMetadata&mid="+code.group(1)}
    return get_file(url)
    
def picasaweb(url):
    url = url.replace('&noredirect=1','')
    
    token = url.split('vkpass_token=')[-1]
    id = re.findall('/(\d+)/', url)[0]
    last_part = url.split('/')[-1]
    date = re.findall('(.*?)\?', last_part)[0]
    authkey = re.findall('authkey=(.*?)#', last_part)[0]
    picasa_id = re.findall('#(\d+)&', last_part)[0]
    
    vkpass = 'http://vkpass.com/token/%s/%s/%s/%s&picasa_id=%s' % (token,id,date,authkey,picasa_id)

    return vkpass

def vk(hoster):
    try:
        hoster = re.search("&url=(.*?$)", hoster).group(1)
    except:
        pass
    # print hoster
    content = requests.get(hoster, headers=headers).text
    file = re.findall('(?:\'|")url720(?:\'|")\s*:\s*(?:\'|")(.+?)(?:\'|")', content)[0]
    return file.replace('\\','')
    
def ok_ru(hoster):
    content = requests.get(hoster, headers=headers).text
    try:
        file = (re.search('"name":"hd","url":"(.*?)"',content).group(1))
        file = file.replace("\u0026", "&")
    except:
        pass
    return file+"&start=0"
    
def uptostream(hoster):
    print "upstostream:   "+str(hoster)
    url = re.search("http://uptostream.com/(.+$)", hoster).group(1)
    # print "HAYDAAAAAA:   "+url
    url= "http://uptostream.com/iframe/"+url
    content = requests.get(url, headers=headers).text
    file = re.search("source src='(.*?)' type='video/mp4'", content).group(1)
    # print file
    return file

def get_domain_list(app,domain_list):
    content = requests.get(app[0]).text
    domains = re.findall("var domains=\[(.*?)\]", content)[0]
    domains = re.findall("'(.*?)'", domains)
    for domain in domains:
        domain_list.append(domain)
    return domain_list

def add_to_library():
    url = args['url'][0]
    name = args['name'][0]
    series_path = addon.getSetting('series_path')
    seriesname = deumlaut((''.join(c for c in unicode(str(name), 'utf-8') if c not in '/\\:?"*|<>')).strip(' .'))
    if series_path:
        staffeln = get_staffeln(url)
        ret = select_season(staffeln)
        staffeln.pop(0)
        if ret == 0:
            for staffel in staffeln:
                add_to_library_2(staffel,seriesname,series_path)
        elif ret > 0:
            staffel = staffeln[ret-1]
            add_to_library_2(staffel,seriesname,series_path)
    else:
        addon.openSettings()
        
def add_to_library_2(staffel,seriesname,series_path):
    season = staffel['staffel']
    url = staffel['url']
    episoden = get_episoden(url)
    for episode in episoden:
        url = episode['url']
        u = url.split('/')[-1]
        try:
            s = re.findall('staffel-(\d+)', url)[0]
        except:
            s = re.findall('-(\d+)-', u)[0]
        e = ''
        try:
            a = re.findall('episode-(.*?)\.', url)[0]
            b = re.findall('(\d+)', a)
        except:
            a = re.findall('.+?-.+?-(.*?)\.', u)[0]
            b = re.findall('(\d+)', a)
        for c in b:
            d = 'E%s' % c
            e += d
        strmname = 'S%s%s.strm' % (s,e)
        strmentry = build_url({'mode': 'play', 'url': url})
        strm = os.path.join(series_path, seriesname, strmname)
        strm = xbmc.makeLegalFilename(strm)
        create_strm_file(strm,strmentry)
    if len(episoden) < 30:
        create_dummy_strms(seriesname, episoden, series_path)
    xbmc.sleep(100)
    xbmc.executebuiltin('UpdateLibrary(video)')

def select_season(seasons):
    seasons.insert(0,{'staffel': 'Alle', 'url': ''})
    selection = []
    for season in seasons:
        name = season['staffel']
        selection.append('Staffel: '+name)
    dialog = xbmcgui.Dialog()
    ret = dialog.select('Select Season', selection)
    return ret
        
def create_dummy_strms(seriesname, episoden, series_path):
    for e in range(len(episoden)+1, 30):
        url = episoden[0]['url']
        u = url.split('/')[-1]
        try:
            s = re.findall('staffel-(\d+)', url)[0]
        except:
            s = re.findall('-(\d+)-', u)[0]
        strmname = 'S%sE%s.strm' % (s,str(e))
        url = re.findall('(.*?episode-)', url)[0]
        url = url.replace('episode-','episode-%s.html' % str(e))
        strmentry = build_url({'mode': 'play', 'url': url})
        strm = os.path.join(series_path, seriesname, strmname)
        strm = xbmc.makeLegalFilename(strm)
        create_strm_file(strm,strmentry)
        
def create_strm_file(strm,strmentry):
    if not xbmcvfs.exists(os.path.dirname(strm)):
        try: 
            xbmcvfs.mkdirs(os.path.dirname(strm))
        except:
            xbmc.executebuiltin('Notification(Info: Konnte keinen Ordner erstellen!,)')
            return
    old_strmentry = ''
    try:
        f = xbmcvfs.File(strm, 'r')
        old_strmentry = f.read()
        f.close()
    except:
        pass
    if strmentry != old_strmentry:
        try:
            file_desc = xbmcvfs.File(strm, 'w')
            file_desc.write(strmentry)
            file_desc.close()
        except:
            xbmc.executebuiltin('Notification(Info: Konnte keine Datei erstellen!,)')
        
def deumlaut(s):
    s = s.encode('utf-8')
    s = s.replace('ß', 'ss')
    s = s.replace('ü', 'ue')
    s = s.replace('Ü', 'Ue')
    s = s.replace('ö', 'oe')
    s = s.replace('Ö', 'Oe')
    s = s.replace('ä', 'ae')
    s = s.replace('Ä', 'Ae')
    return s
    
def addLink(name,url,mode,iconimage):
    u = build_url({'mode': mode, 'name': name, 'url': url})
    item=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Title": name } )
    item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item)

def addDir(name,url,mode,iconimage,cm=''):
    u = build_url({'mode': mode, 'name': name, 'url': url, 'iconimage': iconimage})
    item=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Title": name } )
    if cm: item.addContextMenuItems( cm )
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item,isFolder=True)

def build_url(query):
	return sys.argv[0] + '?' + urllib.urlencode(query)

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
print 'Arguments: '+str(args)

if mode==None:
    list_categories()
else:
    exec '%s()' % mode[0]