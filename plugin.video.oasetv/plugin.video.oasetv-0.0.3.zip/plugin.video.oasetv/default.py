﻿# -*- coding: utf-8 -*-
import urllib,urllib2,os,re,xbmcplugin,xbmcgui,xbmcaddon,datetime,time
import json as api
from addon.common.net import Net
from threading import Thread as doit
import time, datetime

addon_id = 'plugin.video.oasetv'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
status = __settings__.getSetting("status")
datapath = __settings__.getAddonInfo('path')
channels1 = xbmc.translatePath(os.path.join(datapath, 'resources', 'images'))
sys.path.append(channels1)
channels = xbmc.translatePath(os.path.join(datapath, 'lib', 'metahandler'))
sys.path.append(channels)
channels = xbmc.translatePath(os.path.join(datapath, 'lib', 'db'))
sys.path.append(channels)
channels2 = xbmc.translatePath(os.path.join(datapath, 'lib'))
sys.path.append(channels2)
import metahandlers
import common
import jsunpack,unwise
pluginhandle = int(sys.argv[1])
metaget = metahandlers.MetaData(preparezip=True)
USER_AGENT = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:36.0) Gecko/20100101 Firefox/36.0'
IE_USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0) like Gecko'
IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25'
net = Net()
seitenArr = []

def seiteLesen(url):
        net = Net()
        seitenArr.append(net.http_GET(url).content)
        
def SiteScraper(url):
        net = Net()
        link = net.http_GET(url).content
        link=link.replace('\r\n', '').replace('"},]', '"}]')
        magic = api.loads(link, encoding='utf-8')
        total=magic['totalItems']
        sites=int(total/9999)+1
        print sites
        datei=[]
        threads = []
        dietitle = []
        ist = False
        for i in range(int(sites)+1):
            link = doit(seiteLesen("http://www.stream-oase.tv/titles/paginate?perPage=9999&page="+str(i)+"&type=movie"))
            print link
            threads.append(link)
            link.start()
        for i in seitenArr:
            videos = api.loads(i, encoding='utf-8')
            for index, e in enumerate(videos['items']):
                if e['link'] != []:
                    if len(datei)<1:
                        datei.append(e)
                        dietitle.append(e['title'])
                    elif e['title'] not in dietitle:
                            datei.append(e)
                            dietitle.append(e['title'])
                    else:
                        pass
        
        with open(str(channels)+"\\data.txt", 'w+') as outfile:
            api.dump(sorted(datei, key=lambda dat: int(time.mktime(datetime.datetime.strptime(dat['updated_at'], "%Y-%m-%d %H:%M:%S").timetuple()))), outfile)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        win =xbmcgui.Window (xbmcgui.getCurrentWindowId())
        win.close()
        
def CATEGORIES(url):
        addDir("Neu im Programm",url,1,str(channels1)+"\\New-icon-2.png","0","folder","",None,"")
        addDir("Action",url,1,str(channels1)+"\\Action-icon.png","0","folder","",0,"")
        addDir("Adventure",url,1,str(channels1)+"\\Abenteuer-icon.png","0","folder","",0,"")
        addDir("Animation",url,1,str(channels1)+"\\Animation-icon.png","0","folder","",0,"")
        addDir("Biography",url,1,str(channels1)+"\\Abenteuer-icon.png","0","folder","",0,"")
        addDir("Comedy",url,1,str(channels1)+"\\Komoedie-icon.png","0","folder","",0,"")
        addDir("Crime",url,1,str(channels1)+"\\Krimi-icon.png","0","folder","",0,"")
        addDir("Documentary",url,1,str(channels1)+"\\Documentary-icon.png","0","folder","",0,"")
        addDir("Drama",url,1,str(channels1)+"\\Drama-icon.png","0","folder","",0,"")
        addDir("Family",url,1,str(channels1)+"\\Family-icon.png","0","folder","",0,"")
        addDir("Fantasy",url,1,str(channels1)+"\\Fantasy-icon.png","0","folder","",0,"")
        addDir("History",url,1,str(channels1)+"\\History-icon.png","0","folder","",0,"")
        addDir("Horror",url,1,str(channels1)+"\\Horror-icon.png","0","folder","",0,"")
        addDir("Music",url,1,str(channels1)+"\\Musics-icon.png","0","folder","",0,"")
        addDir("Musical",url,1,str(channels1)+"\\Musical-icon.png","0","folder","",0,"")
        addDir("Mystery",url,1,str(channels1)+"\\Mystery-icon.png","0","folder","",0,"")
        addDir("Romance",url,1,str(channels1)+"\\Romance-icon.png","0","folder","",0,"")
        addDir("Sci-Fi",url,1,str(channels1)+"\\Sci-Fi-icon.png","0","folder","",0,"")
        addDir("Thriller",url,1,str(channels1)+"\\Thriller-icon.png","0","folder","",0,"")
        addDir("War",url,1,str(channels1)+"\\Krieg-icon.png","0","folder","",0,"")
        addDir("Western",url,1,str(channels1)+"\\Western-icon.png","0","folder","",0,"")
        addDir("Datenbank aktualisieren",url,5,str(channels1)+"\\Update-icon.png","0","folder","",None,"")
        addDir("FilmInfo sammeln (dauert etwas Geduld bitte!)",url,1,str(channels1)+"\\Update-icon.png","0","folder","",None,"")
        addDir("Search Stream-Oase",url,3,str(channels1)+"\\Search-icon.png","0","folder","",None,"")

def SEARCH(url,name,imdb,move,movegen):
        with open(str(channels)+"\\data.txt", 'r') as link:
            magic = api.loads(link.read(), encoding='utf-8')
        kb = xbmc.Keyboard('', 'Search KinoLeak', False)
        kb.doModal()
        search = kb.getText()
        # search=urllib.quote(search)
        for e,i in enumerate(magic):
            if search.lower() in (i['title'].encode('utf-8')).lower():
                try:
                    imdb=re.search(".*?/(tt\d+)/*.*?$", i['imdblink']).group(1)
                except:
                    imdb=""
                try:
                    sub=re.search("(.*?)\((\d+)\)", i['title'])
                    addDir(sub.group(1),url,2,i['poster'],imdb,"movie".decode('utf-8'),sub.group(2),None,"")
                except:
                    addDir(i['title'],url,2,i['poster'],imdb,"movie",'',None,"")
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('MAIN') )

def INDEX(url,name,imdb,move,movegen):
        with open(str(channels)+"\\data.txt", 'r') as link:
            magic = api.loads(link.read(), encoding='utf-8')
        progress = xbmcgui.DialogProgress()
        progress.create('Fortschritt', 'Warten...')
        genre=[]
        neu=[]
        sammeln=[]
        for e,i in enumerate(reversed(magic)):
            if name == "Neu im Programm" and e<49:
                neu.append(i)
            if name in i['genre'].encode('utf-8'):
                genre.append(i)
            if "sammeln" in name:
                sammeln.append(i)
        #----Neu im Programm----#
        for e,i in enumerate(neu):
            if e < len(neu):
                percent = int((e/len(neu))*100)
                message =   str(e) + " von "+str(len(neu))+" Filmen geladen"
                progress.update(percent, message, "Dies passiert bei noch nie eingelesenen Filmen")
            if not i['imdb_id']:
                imdb='None'
            else:
                imdb=i['imdb_id']
            addDir(i['title'],url,2,i['poster'],imdb,"movie",'',None,"")
        #----GENRES die Filme----#
        for e,i in enumerate(genre):
            if move<=e<move+25:
                if e-move < move+25:
                    percent = ((e-move)/25*100)
                    message =   "FilmInfo des "+str(e-move) + ". von 25 Filmen geladen"
                    progress.update(percent, message, "Dies passiert bei noch nie eingelesenen Filmen")
                if not i['imdb_id']:
                    imdb='None'
                else:
                    imdb=i['imdb_id']
                addDir(i['title'],url,2,i['poster'],imdb,"movie",'',None,"")
        #----FilmInfo von allen Filmen Sammeln für die Datenbank----#
        for e,i in enumerate(sorted(sammeln, key=lambda sammeln: sammeln['title'])):
            if e < len(sammeln):
                percent = int((e/len(sammeln))*100)
                message =   "FilmInfo des "+str(e) + ". von "+str(len(sammeln))+" Filmen geladen"
                progress.update(percent, message, "Dies passiert bei noch nie eingelesenen Filmen")
                if not i['imdb_id']:
                    imdb='None'
                else:
                    imdb=i['imdb_id']
                addDir(i['title'],url,2,i['poster'],imdb,"movie",'',None,"")
        #----SEITENNAVIGATION----#
        if len(genre)>0:
            if move!=None and move==0 and len(genre)>25:
                print "<<<----OLDU-1---->>>"
                addDir("Next-->>",url,4,"","","folder","",move+25,name)
            if move!=None and move!=0 and move+25<=len(genre) and len(genre)-move>0:
                print "<<<----OLDU-2---->>>"
                addDir("Next-->>",url,4,"","","folder","",move+25,name)
                addDir("<<--Back",url,4,"","","folder","",move-25,name)
            if move+25>=len(genre) and move!=0:
                print "<<<----OLDU-3---->>>"
                addDir("<<--Back",url,4,"","","folder","",move-25,name)
            addDir("Home","",None,"","","folder","",None,"")
        progress.close()
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmc.executebuiltin("Container.SetViewMode(515)")

def PLAYLIST(name, url, iconimage, imdb):
        with open(str(channels)+"\\data.txt", 'r') as link:
            magic = api.loads(link.read(), encoding='utf-8')
        liste=[]
        streams=[]
        dialog = xbmcgui.Dialog()
        for i in magic:
            if name in i['title'].encode('utf-8'):
                for e in i['link']:
                    liste.append(e['label'])
                    streams.append(e['url'])
        hoster = dialog.select('HOSTER',liste)
        file = HOSTER(name,streams[hoster],iconimage)
        listitem = xbmcgui.ListItem(path=file)
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def HOSTER(name, url, iconimage):
        if 'vidhog' in url:
            file = resolve_vidhog(name,url,iconimage)
        elif 'mightyupload' in url:
            file = resolve_mightyupload(name,url,iconimage)
        elif 'vk.com' in url:
            file = resolve_VK(name,url,iconimage)
        elif '180upload' in url:
            file = resolve_180upload(name,url,iconimage)
        elif 'cloudyvideos' in url:
            file = resolve_cloudyvideos(name,url,iconimage)
        elif 'ilook' in url:
            file = resolve_ilook(name,url,iconimage)
        elif 'streamin' in url:
            file = resolve_streamin(name,url,iconimage)
        elif 'openload' in url:
            file = resolve_openload(name,url,iconimage)
        elif 'vid.ag' in url:
            file = resolve_vidag(name,url,iconimage)
        elif 'videowood' in url:
            file = resolve_videowood(name,url,iconimage)
        elif 'vidce' in url:
            file = resolve_vidce(name,url,iconimage)
        elif 'filehoot' in url:
            file = resolve_filehoot(name,url,iconimage)
        elif 'allmyvideos' in url:
            file = resolve_allmyvideos(name,url,iconimage)
        elif 'vidzi' in url:
            file = resolve_vidzi(name,url,iconimage)
        else:
            pass
        return file

def resolve_mightyupload(name,url,iconimage):
        print url
        html = net.http_GET(url).content
        form_values = {}
        stream_url = None
        for i in re.finditer('<input type="hidden" name="(.*?)" value="(.*?)"', html):
            form_values[i.group(1)] = i.group(2)
        html = net.http_POST(url, form_data=form_values).content
        r = re.search('<IFRAME SRC="(.*?)" .*?></IFRAME>', html, re.DOTALL)
        if r:
            html = net.http_GET(r.group(1)).content
        r = re.search("<div id=\"player_code\">.*?<script type='text/javascript'>(.*?)</script>", html, re.DOTALL)
        if not r:
            raise UrlResolver.ResolverError('Unable to resolve Mightyupload link. Player config not found.')
        r_temp = re.search("file: '([^']+)'", r.group(1))
        if r_temp:
            stream_url = r_temp.group(1)
        else:
            js = jsunpack.unpack(r.group(1))
            r = re.search("'file','([^']+)'", js.replace('\\', ''))
            if not r:
                r = re.search('"src"value="([^"]+)', js.replace('\\', ''))

            if not r:
                raise UrlResolver.ResolverError('Unable to resolve Mightyupload link. Filelink not found.')

            stream_url = r.group(1)

        if stream_url:
            file = stream_url + '|User-Agent=%s' % (USER_AGENT)
        else:
            raise UrlResolver.ResolverError('Unable to resolve link')
        return file

def resolve_vidzi(name,url,iconimage):
        html = net.http_GET(url).content

        if '404 Not Found' in html:
            raise UrlResolver.ResolverError('File Not Found or removed')

        r = re.search('file\s*:\s*"([^"]+)', html)
        if r:
            return r.group(1) + '|Referer=http://vidzi.tv/nplayer/jwplayer.flash.swf'
        else:
            for match in re.finditer('(eval\(function.*?)</script>', html, re.DOTALL):
                js_data = jsunpack.unpack(match.group(1))
                r = re.search('file\s*:\s*"([^"]+)', js_data)
                if r:
                    return r.group(1)
                    
def resolve_allmyvideos(name,url,iconimage):
        html = net.http_GET(url).content
        file = re.search('"file" : "(.*?)",', html).group(1)
        file = file+"&direct=false&ua=true"
        return file

def resolve_filehoot(name,url,iconimage):
        html = net.http_GET(url).content
        if '404 Not Found' in html:
            dialog = xbmcgui.DialogProgress()
            dialog1 = xbmcgui.Dialog()
            dialog1.ok('error','[UPPERCASE][B]                Sorry but the video is deleted!!![/B][/UPPERCASE]')

        pattern = "file\s*:\s*'([^']+)'\s*,\s*'provider'\s*:\s*'http"
        match = re.search(pattern, html)
        if match:
            file = match.group(1)
        return file

def resolve_videowood(name,url,iconimage):
        data = net.http_GET(url).content
        stream_url = re.search('file:\s*(\'|")(.*?.mp4)(\'|")', data)
        if stream_url:
            file = stream_url.group(2)
        else:
            get_packedjava = re.findall("(eval.function.*?)</script>", data, re.S)
            if get_packedjava:
                sJavascript = re.search("(.*?,)(\d\d)(,\d\d.*?)$", get_packedjava[0], re.S)
                if sJavascript:
                    sJavascript = "%s62%s" % (sJavascript.group(1), sJavascript.group(3))
                    sUnpacked = jsunpack.unpack(sJavascript)
                    if sUnpacked:
                        stream_url = re.search('.*?file(\'|")\s*:\s*(\'|")([^,\s\"]+.mp4)(\'|")', sUnpacked, re.S)
                        if stream_url:
                            file = stream_url.group(3).replace('\\\\/','/')
        return file

def resolve_vidag(name,url,iconimage):
        html = net.http_GET(url).content
        for match in re.finditer('(eval\(function.*?)</script>', html, re.DOTALL):
            js_data = jsunpack.unpack(match.group(1))
            r = re.search('file\s*:\s*"([^"]+)', js_data)
            if r:
                file = r.group(1)
        
        r = re.search('file\s*:\s*"([^"]+)', html)
        if r:
            file = r.group(1)
        return file

def resolve_vidce(name,url,iconimage):
        html = net.http_GET(url).content
        data = {}
        for match in re.finditer('input type="hidden" name="([^"]+)" value="([^"]+)', html):
            key, value = match.groups()
            data[key] = value
        data['method_free'] = 'Proceed to File/Video'
        html = net.http_POST(url, form_data=data).content
        for match in re.finditer('input type="hidden" name="([^"]+)" value="([^"]+)', html):
            key, value = match.groups()
            data[key] = value
        data['method_free'] = 'Proceed to File/Video'
        html = net.http_POST(url, form_data=data).content
        html = html.replace("\\","")
        file = (re.search('document.write\("<a href="(http://\d.*?)"><img src="', html).group(1)).replace(" ", "_")
        return file

def resolve_ilook(name,url,iconimage):
        print "ilook"
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        html=response.read()
        file = re.search('file:\s"(.*?)"',html)
        return file

def resolve_openload(name,url,iconimage):
        print "openload"
        print url
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:36.0) Gecko/20100101 Firefox/36.0')
        response = urllib2.urlopen(req)
        data=response.read()
        parse = re.search('videocontainer.*?text/javascript">(.*?);</script>', data, re.S)
        # print "Parse : "+parse.group(1)
        file = None
        if parse:
            todecode = parse.group(1).split(';')
            todecode = todecode[-1].replace(' ','')

            code = {
            "(ﾟДﾟ) [1]" : "f",
            "(ﾟДﾟ) [c]" : "c",
            "(ﾟДﾟ) [constructor]" : '"',
            "(ﾟДﾟ)[ﾟoﾟ]" : "o",
            "(ﾟДﾟ) [return]" : "\\",
            "(ﾟДﾟ) [ ﾟΘﾟ]" : "_",
            "(ﾟДﾟ) [ ﾟΘﾟﾉ]" : "b",
            "(ﾟДﾟ) [ ﾟωﾟﾉ]" : "a",
            "(ﾟДﾟ) [ ﾟДﾟﾉ]" : "e",
            "(ﾟДﾟ) [ﾟｰﾟﾉ]" : "d",
            "(ﾟДﾟ) ['_']"  : "Function()",
            "(ﾟДﾟ)[ﾟεﾟ]": "/",
            "(ﾟｰﾟ)": "4",
            "(o^_^o)": "9",
            "c": "0",
            "o": "3",
            "ol": "undefined",
            "oﾟｰﾟo": "u",
            "ﾟoﾟ": "constructor",
            "(ﾟΘﾟ)": "1",
            "ﾟεﾟ": "return",
            "ﾟωﾟﾉ": "undefined",
            "_": "3",
            }
            try:
                for searchword,isword in code.iteritems():
                    todecode = todecode.replace(searchword,isword)
                todecode = re.sub(r'\((\d)\+(\d)\)', lambda m: '{0}'.format(int(m.group(1)) + int(m.group(2))), todecode.replace(" ","")).replace(" ","")
                todecode = re.sub(r'\((\d)\^(\d)\^(\d)\)', lambda m: '{0}'.format(int(m.group(1)) ^ int(m.group(2))^ int(m.group(3))), todecode).replace(" ","")
                todecode = re.sub(r'\((\d)\+(\d)\)', lambda m: '{0}'.format(int(m.group(1)) + int(m.group(2))), todecode).replace(" ","")
                todecode = re.sub(r'\((\d)\-(\d)\)', lambda m: '{0}'.format(int(m.group(1)) - int(m.group(2))), todecode).replace(" ","")
                todecode = re.sub(r'\((\d)\+(\d)\+(\d)\)', lambda m: '{0}'.format(int(m.group(1)) + int(m.group(2))+ int(m.group(3))), todecode).replace(" ","")
                todecode = re.sub(r'\((\d)\-(\d)\+(\d)\)', lambda m: '{0}'.format(int(m.group(1)) - int(m.group(2))+ int(m.group(3))), todecode).replace(" ","")
                todecode = re.sub(r'\((\d)\+(\d)\-(\d)\)', lambda m: '{0}'.format(int(m.group(1)) + int(m.group(2))- int(m.group(3))), todecode).replace(" ","")
                thestring =  re.search("return3(.*?)\d\)", todecode.replace("+","")).group(1).replace("/","\\")
                if thestring:
                    thestring =  unicode(thestring, 'unicode-escape').replace('\\/','/')
                    print thestring
                    url = re.search('window.vr ="(.*?)";window.vt ="video/mp4" ;', thestring)
                    if url:
                        file = url.group(1)
            except Exception as e:
                print "ERROR parsing openload code"
        print file
        return file

def resolve_streamin(name,url,iconimage):
        print "streamin"
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        html=response.read()
        file = re.search('file:\s"(.*?)"', html)
        url = file.group(1)
        return url

def resolve_cloudyvideos(name,url,iconimage):
        print "cloudyvideos"
        url=re.sub('embed-|-.*?(?:\.html)','',url)
        net = Net()
        web_url = url
        headers = {'Referer': web_url}
        html = net.http_GET(web_url, headers=headers).content
        data={}
        time.sleep(3)
        for match in re.finditer(r'type="hidden".*?name="([^"]+)".*?value="([^"]+)', html):
            data[match.group(1)] = match.group(2)
            data.update ({'method_free': 'Continue'})
        htmla = net.http_POST(web_url, data).content
        r = re.search('file:\s*\'(.*?)\',+', htmla)
        return r.group(1)+'|Referer=http://cloudyvideos&User-Agent=%s' % (USER_AGENT)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

def addDir(name,url,mode,iconimage,imdb,status,year,move,movegen):
        u = build_url({'mode': mode, 'name': name.encode('utf-8'), 'url': url, 'img': iconimage, 'imdb': imdb, 'move': move, 'movegen': movegen})
        # u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name.encode('utf-8'))+"&img="+urllib.quote_plus(iconimage)+"&imdb="+urllib.quote_plus(imdb)+"&move="+str(move)+"&movegen="+str(movegen)
        # ok=True
        if status!="folder":
            try:
                meta = metaget.get_meta(status,name.encode('utf-8'),imdb.encode('utf-8'))
            except:
                meta = {'backdrop_url': ''}
            try:
                meta['duration'] = int(meta['duration'])*60
            except:
                pass
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels=meta )
            liz.setInfo( type="Video", infoLabels={"overlay": 7, "watched": True} )
            contextMenuItems = []
            contextMenuItems.append(('Film Information', 'XBMC.Action(Info)'))
            liz.addContextMenuItems(contextMenuItems, replaceItems=False)
            if not meta['backdrop_url'] == '': liz.setProperty('fanart_image', "http://image.tmdb.org/t/p/original"+meta['backdrop_url'])
            else: liz.setProperty('fanart_image', '')
            liz.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=liz)
            # ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=True
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name } )
            contextMenuItems = []
            liz.addContextMenuItems(contextMenuItems, replaceItems=False)
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
            return ok

def build_url(query):
        return sys.argv[0] + '?' + urllib.urlencode(query)   

params=get_params()
url=None
name=None
mode=None
iconimage=None
imdb=None
move=None
movegen=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["thumbnailImage"])
except:
        pass
try:
        imdb=urllib.unquote_plus(params["imdb"])
except:
        pass
try:
        move=int(params["move"])
except:
        pass
try:
        movegen=urllib.unquote_plus(params["movegen"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        CATEGORIES('http://www.stream-oase.tv/titles/paginate?perPage=9999&page=1&order=mc_num_of_votesDesc&type=movie&minRating=&maxRating=')
elif mode==1:
        INDEX(url,name,imdb,move,movegen)
elif mode==2:
        PLAYLIST(name, url, iconimage, imdb)
elif mode==3:
        SEARCH(url,name,imdb,move,movegen)
elif mode==4:
        print ""+url
        INDEX(url,movegen,imdb,move,movegen)
elif mode==5:
        SiteScraper("http://www.stream-oase.tv/titles/paginate?perPage=1&page=1&type=movie")



xbmcplugin.endOfDirectory(int(sys.argv[1]))
