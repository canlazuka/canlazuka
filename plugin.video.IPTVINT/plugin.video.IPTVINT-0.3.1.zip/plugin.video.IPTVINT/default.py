#!/usr/bin/python
# -*- coding: utf-8 -*-
import cgi,urllib,urllib2,re,xbmcplugin,xbmcgui,json,xbmcaddon
from cookielib import CookieJar
from BeautifulSoup import BeautifulSoup
xbmcPlayer = xbmc.Player()
__settings__ = xbmcaddon.Addon(id="plugin.video.IPTVINT")
cj = CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

def url_opener():
        login= __settings__.getSetting("login")
        password= __settings__.getSetting("password")
        data = {
                    'cookieuser':'1',
                    'web_name_u': login,
                    'web_name_p': password,
                    'action':'Login',
                    'submit':'Login',
                    }
        login = 'http://hasbahcaiptv.com/admin.php'
        # opener.open(login, urllib.urlencode(data)).read()

def CATEGORIES():
        url_opener()
        #~ addDir("TEST",'http://database.freetuxtv.net/playlists/playlist_webtv_tr.m3u',1,'')
        addDir("Almanca TV",'https://dl.dropboxusercontent.com/s/5y9z7d357kgzjts/iptv%20tiny.cc.m3u?dl=1',1,'')
        addDir(u"Radyodelisi (T\xfcrk\xe7e TV)".encode('utf-8'),'http://radyodelisi.blogspot.com.tr/2014/06/radyo-delisi-simple-tv-extm3u-dosyasi_16.html',1,'')
        addDir(u"Favori (T\xfcrk\xe7e TV)".encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Turkey_TURKiYE_Favori.m3u',1,'')
        addDir(u"Ulusal (T\xfcrk\xe7e TV)".encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Turkey_TURKiYE_ULUSAL.m3u',1,'')
        addDir(u"Ulusal yedek (T\xfcrk\xe7e TV)".encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Turk_ulusal_yedek.m3u',1,'')
        addDir(u"K\xfcreTV".encode('utf-8'),'http://cartoonnetwork.web.tv/',6,'')
        addDir(u"T\xfcrk\xe7e WebTV".encode('utf-8'),'http://cartoonnetwork.web.tv/',2,'')
        addDir(u"T\xfcrkiye yerel".encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Turkey_TURKiYE_YEREL.m3u',1,'')
        # addDir(u"TRT".encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/trt.m3u',1,'')
        addDir(u'Dt\xfcrk & Dsmart'.encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/DTURK_DSMART.m3u',1,'')
        addDir(u'Music_MUZiK'.encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Music_MUZiK.m3u',1,'')
        addDir(u'SPOR'.encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Sport_SPOR.m3u',1,'')
        addDir(u'T\xfcrk komple'.encode('utf-8'),'http://hasbahcaiptv.com/m3u/iptv/iptv/Turkkomple.m3u',1,'')
        addDir(u'T\xfcrk filimleri'.encode('utf-8'),'http://hasbahcaiptv.com/m3u/movies/Turk_Filmleri.m3u',1,'')
        addDir(u'\xc7izgi Filimler'.encode('utf-8'),'http://hasbahcaiptv.com/m3u/movies/cartoons.m3u',1,'')
        addDir('Ingilizce Filimler','http://hasbahcaiptv.com/m3u/movies/englishmovies.m3u',1,'')
        addDir(u'IPTV türk'.encode('utf-8'),'http://myipbox.org/turkiptv.xml',5,'')
        addDir(u'IPTV türk-2'.encode('utf-8'),'http://myipbox.org/turkish.xml',5,'')
        addDir('IPTV komple','http://myipbox.org/iptv.xml',5,'')
        addDir('IPTV komple-2','http://myipbox.org/iptv2.xml',5,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def main(url):
        linkget=opener.open(url).read()
        soup = BeautifulSoup(linkget)
        panel1 = soup.findAll("div", {"class": "kanallar-slide"},smartQuotesTo=None)
        agelenadres = re.compile('<a href="(.*?)" title="(.*?) Canlı izle" class=".*?" style=".*?url\((.*?)\);"></a>').findall(str(panel1))
        for linkler,name2,thumbnail in agelenadres:
            name=str(name2)
            thumbnail=str(thumbnail)
            addDir('[COLOR orange][B]'+str(name)+'[/B][/COLOR]',str(linkler),4,thumbnail)
        xbmc.executebuiltin("Container.SetViewMode(500)")

def kuere(url):
        kure=[("Samanyolu", "http://www.kure.tv/liveembed?id=1"), ("Samanyolu Haber", "http://www.kure.tv/liveembed?id=2"), ("Mehtap TV", "http://www.kure.tv/liveembed?id=3"), ("Yumurcak", "http://www.kure.tv/liveembed?id=4")]
        for name, url in kure:
            linkget=opener.open(url).read()
            link=re.search("file: '(.*?)',", linkget).group(1)
            addLink(name,link,"")

def TURK(url):
        req = urllib2.Request(url,None,{'User-agent': 'Mozilla/5.0 seyirTURK_KODI (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        print "BURASIIIII   "+link
        for i in json.loads(link):
            name = i['Baslik'].encode('utf-8')
            url = i['Stream'].encode('utf-8')
            img = i['Logo'].encode('utf-8').replace(" ","")
            if "HasBahCa" not in name and "Radyo Delisi" not in name:
                addLink(name,url.replace("\\",""),img.replace("\\",""))

def INDEX(url):
        status=True
        while status==True:
            try:
                link = opener.open(url).read()
                # print link
                status = False
            except:
                status = True
        genre = ["ADULT","ARABESK","ALATURKA","TRT RADYO","TÜRKÜ"]
        try:
            match=re.compile('#EXTINF:.*?\$ExtFilter="(.*?)"\stvg-logo="(.*?)",(.*?)\r*\n+(.*?)\r*\n+').findall(link)
            # match=re.compile('#EXTINF:.*?,(.*?)\r*\n+(.*?)\r*\n+').findall(link)
            if len(match)>1:
                for a,i,e,f in match:
                    if any(a == o for o in genre):
                        pass
                    else:
                        addLink(e.replace('***HasBahCa','***').replace('by_HasBahCa',''),f.replace('<swfUrl>',' swfUrl=').replace('<pageUrl>',' pageUrl=').replace('<live>',' live=') .replace('<playpath>',' playpath=').replace('<playpath>',' playpath=').replace('<object encoding>','').replace('rtmp://$OPT:rtmp-raw=','').strip(),i)
            else:
                error
        except:
            match=re.compile('#EXTINF:.*?,(.*?)\r*\n+(.*?)\r*\n+').findall(link)
            for i,e in match:
                addLink(i.replace('***HasBahCa','***').replace('by_HasBahCa',''),e.replace('<swfUrl>',' swfUrl=').replace('<pageUrl>',' pageUrl=').replace('<live>',' live=') .replace('<playpath>',' playpath=').replace('<playpath>',' playpath=').replace('<object encoding>','').replace('rtmp://$OPT:rtmp-raw=','').strip(),"")
        xbmc.executebuiltin("Container.SetViewMode(400)")

def VIDEOLINKS(name,url,thumbnail):
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        name=str(name)
        thumbnail=str(thumbnail)
        media = str(url)
        value=[]
        playList.clear()
        value.append((name,Player(media)))
        if value:
            for name,url in value:
                addLink(str(name),url,thumbnail)
                listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
                listitem.setInfo('video', {'name': name })
                playList.add(url,listitem=listitem)
            xbmcPlayer.play(playList)
            return exit()
        else:
             print "[COLOR blue][B]XTTMC[/B][/COLOR]","[COLOR blue][B]Link Bulunamadi[/B][/COLOR]"

def Player(url):
        linking=opener.open(url).read()
        soup = BeautifulSoup(str(linking))
        panel = soup.findAll("script", {"type": "text/javascript"})
        gelenadres = re.compile("null,\"mediaUrl\":\"(.*?)\",\"adsUrls").findall(str(panel).replace('\\',""))
        gelenadresa= re.compile(".*?http(.*?)index\.m3u8.*?index\.m3u8.*?").findall(str(gelenadres))
        for tere in gelenadresa:
            gelenurl = "http"+str(tere)+"index.m3u8"
            return gelenurl

def xml_coz(url):
        link = opener.open(url).read()
        try:
            print "CHANNEL"
            soup = BeautifulSoup(link)
            panel = soup.findAll("channel")
            for i in panel:
                name = i.find('name').find(text=True)
                url = i.find('address').find(text=True)
                addLink(name,url,"")
        except:
            print "ITEM"
            match = re.compile("\<title\>(.*?)\</title\>\n\t\<link\>(.*?)\</link\>").findall(link)
            for name,url1 in match:
                addLink(name,url1,"")

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None
img=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        # print ""
        CATEGORIES()

elif mode==1:
        print ""+url
        INDEX(url)
elif mode==2:
        print ""+url
        main(url)
elif mode==3:
        TURK(url)
elif mode==4:
        VIDEOLINKS(name,url,img)
elif mode==5:
        xml_coz(url)
elif mode==6:
        kuere(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
