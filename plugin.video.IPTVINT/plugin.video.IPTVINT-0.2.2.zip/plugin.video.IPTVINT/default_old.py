
import cgi,urllib,urllib2,re,xbmcplugin,xbmcgui,json
from cookielib import CookieJar
cj = CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

def url_opener(url):
        # login= __settings__.getSetting("login")
        login= "marangoz"
        # password= __settings__.getSetting("password") 
        password= "bibob1453" 
        data = {
                    'cookieuser':'1',
                    'web_name_u': login,
                    'web_name_p': password,
                    'action':'Login',
                    'submit':'Login',
                    }
        login = 'http://hasbahcaiptv.com/admin.php'
        opener.open(login, urllib.urlencode(data)).read()
        uri = opener.open(url).read()
        print uri
        
def CATEGORIES():
        addDir('TURK TV','http://209.240.106.40/main/vip.php?filter=var&url=%EF%BE%1C%CE%86%DAw9%ED%0B%7F%23%88%2Bf%F5Cy%8C0%8E%BD%1E%98%8B%8EH%CD%88%02%E7%93%A9%A5%2FZB%7C%22%3F',1,'')
        addDir('IPTV INT','http://209.240.106.40/main/vip.php?filter=var&url=%B4%7D%D9%82%CA%A8%19%D1%81%C75%25%5BL%FE%CC%E6%E9s%95%29%C4%CD%A2%D0%EE%81%3B%A4%E1%0A%F4%5B%28%A8KF%0C%97%82%06%24f%B6%0E%F0%DE%EE',1,'')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def TURK(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        for i in json.loads(link):
            if i['Playlist']=="":
                name = (i['Baslik'].encode('utf-8')).replace("HasBahCa","")
                url = i['Stream'].encode('utf-8')
                if "hasbahca" not in i['Logo'].encode('utf-8').replace(" ",""):
                    img = i['Logo'].encode('utf-8').replace(" ","")
                else:
                    img = "icon.png"
                if "HasBahCa" not in name and "Radyo Delisi" not in name:
                    addLink(name,url.replace("\\",""),img.replace("\\",""))
            elif i['Stream']=="":
                name = i['Baslik'].encode('utf-8')
                url = i['Playlist'].encode('utf-8')
                img = i['Logo'].encode('utf-8').replace(" ","")
                if "HasBahCa" not in name and "Radyo Delisi" not in name:
                    addDir(name,url.replace("\\",""),1,img.replace("\\",""))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=str(iconimage))
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&img="+urllib.quote_plus(iconimage)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None
img=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        img=urllib.unquote_plus(params["img"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

# print "Mode: "+str(mode)
print "URL: "+str(url)
# print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        # print ""
        CATEGORIES()
        m3u=url_opener("http://hasbahcaiptv.com/m3u/iptv/Turkey_TURKiYE_ULUSAL.m3u")
        print m3u
elif mode==1:
        TURK(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
