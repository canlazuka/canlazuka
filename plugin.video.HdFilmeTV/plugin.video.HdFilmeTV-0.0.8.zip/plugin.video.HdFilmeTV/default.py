# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui
from BeautifulSoup import BeautifulSoup as BS
import codecs, base64, json
from cookielib import CookieJar
pluginhandle = int(sys.argv[1])
#TV DASH - by You 2008.
cj = CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
opener.addheaders = [('Referer', "http://hdfilme.tv/")]
def url_opener(url):
        # login= __settings__.getSetting("login")
        # password= __settings__.getSetting("password")
        data = {
                    '_submit': 'true',
                    'email': 'maceraci@freenet.de',#login,
                    'password': 'bibob1453',#password,
                    'remember': 'on'
                }
        login = 'http://hdfilme.tv/login.html'
        opener.open(login, urllib.urlencode(data)).read()
        uri = opener.open(url).read()
        return uri
        
def CATEGORIES(url):
        addDir("Suche","http://hdfilme.tv/movie/search?key=",4,'')
        addDir("Serien","http://hdfilme.tv/movie-series?&per_page=0",1,'')
        addDir("Kinofilme","http://hdfilme.tv/movie-movies?&per_page=",1,'')
        addDir("Abenteuer","http://hdfilme.tv/movie-movies?cat=72&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Action","http://hdfilme.tv/movie-movies?cat=73&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Animation","http://hdfilme.tv/movie-movies?cat=74&country=&order_f=id&order_d=desc&per_page=0",2,'')
        addDir("Drama","http://hdfilme.tv/movie-movies?cat=62&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Fantasy","http://hdfilme.tv/movie-movies?cat=66&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Horror","http://hdfilme.tv/movie-movies?cat=69&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Komödie","http://hdfilme.tv/movie-movies?cat=71&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Krimi","http://hdfilme.tv/movie-movies?cat=78&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Sci-Fi","http://hdfilme.tv/movie-movies?cat=84&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Romance","http://hdfilme.tv/movie-movies?cat=83&country=&order_f=id&order_d=desc&per_page=0",1,'')
        addDir("Thriller","http://hdfilme.tv/movie-movies?cat=88&country=&order_f=id&order_d=desc&per_page=0",1,'')
        xbmc.executebuiltin("Container.SetViewMode(300)")
        
def SEARCH(url):
        kb = xbmc.Keyboard('', 'Search Dokuhouse', False)
        kb.doModal()
        search = kb.getText()
        search=urllib.quote(search)
        url_search = url+search
        INDEX(url_search)
        
def INDEX(url1):
        link = opener.open(url1).read()
        movies = re.findall('data-popover="movie-data.*?">\s*<a href="(.*?)">\s*<img.*?src="(.*?)".*?alt="(.*?)"', link, re.I)
        if "series" not in url1:
            for url,bild,title in movies:
                addLink(title,url,2,bild)
        else:
            for url,bild,title in movies:
                addDir(title,url,5,bild)
        ## Pagination ##
        try:
            pages = re.search('<i class="fa fa-caret-down"></i> Seite (\d+)/(\d+)</a>', link)
            new_url = re.search("(http://hdfilme.tv/.*?\?&per_page=)",url1).group(1)
            if int(pages.group(1))>1:
                zahl = ((int(pages.group(1))-1)*50)-50
                addDir("Zurück",new_url+str(zahl),1,'')
            if int(pages.group(2))>int(pages.group(1)):
                zahl = int(pages.group(1))*50
                addDir("Weiter",new_url+str(zahl),1,'')  
        except:
            pass
        xbmc.executebuiltin("Container.SetViewMode(300)")

def INDEX_SER(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        episodes = re.findall('href="(http://hdfilme.tv/.*?\?episode\=.*?\&sv\=.*?)" >', link, re.I)
        for e in episodes:
            eps = re.search("http://hdfilme.tv/.*?\?episode\=(.*?)\&sv\=.*?", e).group(1)
            addLink("Episode "+eps,e,2,"")

def PLAY(name,url,iconimage):
        if not url.startswith('http'):
            stream_url = str(codecs.decode(base64.decodestring(url), 'rot_13'))
        else:
            stream_url = url
        if stream_url.startswith('http://hdfilme.tv/'):
            stream_url = extractStream(url.replace("info", "stream"))
        elif '.youtube.' in stream_url:
            m = re.search('\?v=(.*?)(&|)', stream_url)
            if m:
                id = m.group(1)
                title = self.makeTitle()
                self.session.open(
                    YoutubePlayer,
                    [(title, id, self.cover)],
                    playAll = False,
                    showPlaylist=False,
                    showCover=True
                    )
            else:
                pass
        else:
            listitem = xbmcgui.ListItem(path=stream_url)
        listitem = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def extractStream(url):
        data = url_opener(url)
        try:
            link = re.search('iframe src="(.*?)" width=', data).group(1)
        except:
            pass
        jasonit = url_opener(link)
        try:
            g = re.search('"progressive":(\[.*?\])', jasonit).group(1)
            m = re.search('"progressive":(\[.*?\])', jasonit)
            print g
        except:
            pass
        # try:
            # g = re.search("'sources' : (\[.*?\])", data).group(1)
            # m = re.search("'sources' : (\[.*?\])", data)
        # except:
            # pass
        d = json.loads('{"streams":%s}' % m.group(1)) if m else {}
        liste=[]
        v_liste=[]
        dialog = xbmcgui.Dialog()
        for stream in d.get('streams'):
            liste.append(stream['quality'])
            v_liste.append(stream['url'])
        quality = dialog.select('Quality',liste)
        return v_liste[quality]
        
# def extractStream(url):
        # data = url_opener(url)
        # try:
            # g = re.search('var hdfilme6 = (\[.*?\])', data).group(1)
            # m = re.search('var hdfilme6 = (\[.*?\])', data)
        # except:
            # pass
        # try:
            # g = re.search("'sources' : (\[.*?\])", data).group(1)
            # m = re.search("'sources' : (\[.*?\])", data)
        # except:
            # pass
        # d = json.loads('{"streams":%s}' % m.group(1)) if m else {}
        # liste=[]
        # v_liste=[]
        # dialog = xbmcgui.Dialog()
        # for stream in d.get('streams'):
            # liste.append(stream['label'])
            # v_liste.append(stream['file'])
        # quality = dialog.select('Quality',liste)
        # return v_liste[quality]

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,mode,iconimage):
        u = build_url({'mode': mode, 'name': name, 'url': url})
        item=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        item.setInfo( type="Video", infoLabels={ "Title": name } )
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item)


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def build_url(query):
        return sys.argv[0] + '?' + urllib.urlencode(query)        

params=get_params()
url=None
name=None
mode=None
iconimage=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        id=urllib.unquote_plus(params["id"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["thumbnailImage"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES('http://hdfilme.tv/')
       
elif mode==1:
        print ""+url
        url_opener(url)
        INDEX(url)
        
elif mode==3:
        print ""+url
        VIDEOIDX(url)
        
elif mode==2:
        PLAY(name,url,iconimage)
        
elif mode==4:
        SEARCH(url)
        
elif mode==5:
        INDEX_SER(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
