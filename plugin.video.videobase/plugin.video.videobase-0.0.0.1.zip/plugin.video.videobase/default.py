# VideoBASE plugin written by Mentality
# -*- coding: utf-8 -*-
import re,os,urllib,urllib2
import xbmcplugin,xbmcgui,xbmc
import xbmcaddon
import videobase as enter
from BeautifulSoup import BeautifulSoup as BS

__settings__ = xbmcaddon.Addon(id="plugin.video.videobase")
addon_id = 'plugin.video.videobase'
addon = xbmcaddon.Addon(addon_id)
status = __settings__.getSetting("status")
VIEW = re.search(".*?\((.*?)\)",addon.getSetting('MAIN')).group(1)
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param

params=get_params()
method=None
url=None
url0=None
name=None
mode=None
iconimage=None
imdb=None
plot=None
mpaa=None
trailer=None
serien_name=None
imdb_id=None
tvdb_id=None
season=None
year=None

try:
        method = urllib.unquote_plus(params["method"])
except:
        pass
try:
        url=urllib.unquote_plus(params['url'])
except:
        pass
try:
        url0=urllib.unquote_plus(params['url0'])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        iconimage=''
try:
        imdb=urllib.unquote_plus(params["imdb"])
except:
        imdb=''
try:
        plot=urllib.unquote_plus(params["plot"])
except:
        plot=''
try:
        mpaa=urllib.unquote_plus(params["mpaa"])
except:
        mpaa=''
try:
        serien_name=urllib.unquote_plus(params["serien_name"])
except:
        serien_name=''
try:
        season=urllib.unquote_plus(params["season"])
except:
        season=''
try:
        episode=urllib.unquote_plus(params["episode"])
except:
        episode=''
try:
        tvdb_id=str(params["tvdb_id"])
except:
        pass
try:
        imdb_id=str(params["imdb_id"])
except:
        pass
try:
        year=params["year"]
except:
        year=''

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if method == None:
    enter.INDEX_GENRE("http://crynet.to/forum/content.php")
    xbmc.executebuiltin("Container.SetViewMode(%d)" % 50 )
else:
    #~ print "DEFAULT : "+tvdb_id
    exec "enter."+str(method)
    if "IMDB" in method:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % 50 )
    # elif "GENRES" in method:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % 50 )
    # elif "CENTURY" in method:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % 50 )
    elif "INDEX" in method:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmc.executebuiltin("Container.SetViewMode(%s)" % VIEW )
    elif "Staffel" in name:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmc.executebuiltin("Container.SetViewMode(%s)" % VIEW )
    elif serien_name:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmc.executebuiltin("Container.SetViewMode(%d)" % 500 )
    else:
        pass
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
