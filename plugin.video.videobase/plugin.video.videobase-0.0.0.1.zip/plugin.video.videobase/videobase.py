#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import sys,re,os,urllib2,urllib,httplib
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulSoup as BS
from cookielib import CookieJar
cj = CookieJar()
import HTMLParser
html_parser = HTMLParser.HTMLParser()
addon_id = 'plugin.video.videobase'
addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(addon_id)
datapath = __settings__.getAddonInfo('path')
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
opener.addheaders = [('Referer', "http://crynet.to/forum/forum.php")]
library_path=xbmc.translatePath(__settings__.getSetting("folder"))
library_serie=xbmc.translatePath(__settings__.getSetting("serfolder"))
library_serie=library_serie.replace("smb:","")
library_path=library_path.replace("smb:","")
channels = xbmc.translatePath(os.path.join(datapath, 'lib', 'metahandler'))
sys.path.append(channels)
channels = xbmc.translatePath(os.path.join(datapath, 'lib', 'db'))
sys.path.append(channels)
quality= __settings__.getSetting("quality")
login= __settings__.getSetting("login")
password= __settings__.getSetting("password")
infoscrap = __settings__.getSetting("metahandler")
import metahandlers
metaget = metahandlers.MetaData(preparezip=False)
url_start='http://crynet.to/forum/content.php'
collection = ( "Saga","Trilogie","Collection","Trilogy","Quadrologie","Quadrilogy","Anthologie" )
VIEW = re.search(".*?\((.*?)\)",addon.getSetting('MAIN')).group(1)

def url_opener(url):
        login= __settings__.getSetting("login")
        password= __settings__.getSetting("password")
        data = {
                    'cookieuser':'1',
                    'vb_login_username': login,
                    'vb_login_password': password,
                    'do':'login',
                    'submit':'anmelden',
                    }
        login = 'http://crynet.to/forum/login.php?do=login'
        opener.open(login, urllib.urlencode(data)).read()
        uri = opener.open(url).read()
        # print uri
        if str('<span style="color: #FF6600;">Premium Member</span>') in str(uri) or '.mkv' in str(uri) or '.mp4' in str(uri):
            print "Succesfully Loged in."
            return uri
        else:
            __settings__.openSettings()


def INDEX_GENRE(url):
        data = url_opener(url)
        enter_addDir(' Suche...','http://crynet.to/forum/content.php?r=1969-Aktuelle-HD-Filme&page=','',"SEARCH(url)",'','','','','','','folder','','','','')
        enter_addDir(' Neueinsteiger',url,'',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' 3D Filme','http://crynet.to/forum/content.php?r=4225-3d-filme','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' HD Filme','http://crynet.to/forum/content.php?r=1669-hd-filme','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' HD Collection','http://crynet.to/forum/content.php?r=3501-hd-collection','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' HD Serien','http://crynet.to/forum/content.php?r=5993-Serien','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' Aktuelle HD Filme','http://crynet.to/forum/content.php?r=3938-Aktuelle-HD-Filme','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' 3D Charts','http://crynet.to/forum/content.php?r=5440-3d-charts','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' HD Charts','http://crynet.to/forum/content.php?r=1989-HD-Charts','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' Serien Charts','http://crynet.to/forum/content.php?r=1997-serien-charts','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' Cineline','http://crynet.to/forum/list.php?r=category/169','',"INDEX(url,name)",'','','','','','','folder','','','','')
        enter_addDir(' IMDB Ranking',url_start,'',"INDEX_IMDB(url)",'','','','','','','folder','','','','')
        enter_addDir(' HD Genres',url_start,'',"HD_GENRES(url)",'','','','','','','folder','','','','')
        enter_addDir(' Century',url_start,'',"INDEX_CENTURY(url)",'','','','','','','folder','','','','')
        # xbmc.executebuiltin("Container.SetViewMode(%s)" % "50" )

def HD_GENRES(url):
        data = url_opener(url)
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">HD:(.*?)</a>\n</div>').findall(data)
        for url,name in match:
            # print name
            enter_addDir(str(name.decode('iso-8859-1').encode('utf-8')),url,'',"INDEX(url,name)",'','','','','','','folder','','','','')
        # xbmc.executebuiltin("Container.SetViewMode(50)")

def INDEX_IMDB(url):
        data = url_opener(url)
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">IMDB(.*?)</a>\n</div>').findall(data)
        for url,name in match:
            enter_addDir('IMDB'+str(name),url,'',"INDEX(url,name)",'','','','','','','folder','','','','')
        # xbmc.executebuiltin("Container.SetViewMode(50)")

def INDEX_CENTURY(url):
        data = url_opener(url)
        match=re.compile('<div class="cat_main_menuitem">\n<a href="(.*?)">(Jahr.*?)</a>').findall(data)
        for url,name in match:
            enter_addDir(str(name),url,'',"INDEX(url,name)",'','','','','','','folder','','','','')
        # xbmc.executebuiltin("Container.SetViewMode(50)")

def INDEX(url,name1):
        data = url_opener(url)
        origin_name= name1
        value=[]
        link=data
        soup = BS(link.decode('iso-8859-1','ignore'))
        progress = xbmcgui.DialogProgress()
        if 'Collection' in name1:
            for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
                attr= div.findAll('a')
                name= (attr[0].find(text=True)).encode('utf-8').replace('&amp;','&')
                url= (attr[0]['href']).encode('utf-8')
                resim=div.find('img')['src']
                try:
                    value.append((str(name),resim,url,((attr[2].string).replace("IMDB ",""))))
                except:
                    value.append((str(name),resim,url,''))
            for name, resim, url, imdb in value:
                ADDIR_NEW(str(name.replace("HD: ","")),url,'',"LINKS_COLLECTIONS(url)",resim,imdb,'','','','','movie','','','','')
            match=re.compile('<span><a href=".*?" title=".*?Ergebnis (.*?) von.*?">(.*?)<').findall(data)
            for name, zahl in match:
                ADDIR_NEW('Collections '+str(name.replace("HD: ","")),'http://crynet.to/forum/content.php?r=3501-hd-collection&page='+str(zahl),'',"INDEX(url,name)",'','','','','','','folder','','','','')
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
            # xbmc.executebuiltin("Container.SetViewMode(%s)" % str(VIEW))


        else:
            progress.create('Fortschritt', 'This is a progress bar.')
            for div in soup.findAll('div',  {"class": "article_preview"},smartQuotesTo=None):
                attr= div.findAll('a')
                # print attr
                name= (attr[0].find(text=True)).encode('utf-8').replace('&amp;','&')
                url= (attr[0]['href']).encode('utf-8')
                resim=div.find('img')['src']
                if "Serie" in str(attr[1].string):
                    value.append((str(name),resim,url,'',str(attr[1].string),attr[2].string))
                elif "Cineline" in attr:
                    value.append((str(name),resim,url,'',str(attr[1].string),attr[4].string))
                else:
                    try:
                        value.append((str(name),resim,url,attr[2].string,str(attr[1].string),attr[3].string))
                    except:
                        value.append((str(name),resim,url,attr[2].string,str(attr[1].string),''))

            for i, (name, resim, url, imdb, status,jahr) in enumerate(value):
                if i < len(value):
                    percent = int((i/len(value))*100)
                    message =   str(i) + " von "+str(len(value))+" Filmen geladen"
                    progress.update(percent, message, "Dies passiert bei noch nie eingelesenen Filmen")
                collection = ( "Saga","Trilogie","Collection","Trilogy","Quadrologie","Quadrilogy","Anthologie" )
                col = "xxxxxxxx"
                name = cleanFilename(name)
                for i in collection:
                    if i in name:
                        ADDIR_NEW(str(name),url,'',"LINKS_COLLECTIONS(url)",resim,imdb,'','','',jahr,"movie",'','','','')
                        col = i
                if col !=None:
                    pass
                if 'Serie' in status:
                    ADDIR_NEW(str(name),url,'',"LINKS_SERIE(name,url,iconimage,serien_name,season,tvdb_id)",resim,'','','','',jahr,"tvshow",str(name),'','','')                        
                elif '3D' in name:
                    if quality=='0' or quality=='1':
                        ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'strm','','','')
                    else:
                        ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'','','','')
                elif col not in name and jahr==r'\d*':
                    if quality=='0' or quality=='1':
                        # print imdb, status, jahr
                        ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'strm','','','')
                    else:
                        ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'','','','')
                elif col not in name:
                    try:
                        if (quality=='0' or quality=='1'):
                            ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'strm','','','')
                        else:
                            ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'','','','')
                    except:
                        if jahr!=None:
                            if (quality=='0' or quality=='1'):
                                ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'strm','','','')
                            else:
                                ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',jahr,"movie",'','','','')
                        else:
                            ADDIR_NEW(str(name),url,'',"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",resim,str(imdb),'','','',str(imdb),"movie",'','','','')
            match=re.compile('<span><a href="(.*?)" title="(.*?)">').findall(data)
            for url1,name1 in match:
                try:
                    token=re.search('&(.*?)page=', url1).group(1)
                    url1 = url1.replace(token, "")
                except:
                    pass
                if 'Serie' in origin_name:
                        name1=name1+" Serie"
                ADDIR_NEW(name1,url1,'',"INDEX(url,name)",'','','','','','',"folder",'','','','')
            # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
            # xbmc.executebuiltin("Container.SetViewMode(%s)" % str(VIEW))

def SEARCH(url1):
        login= __settings__.getSetting("login")
        password= __settings__.getSetting("password")
        kb = xbmc.Keyboard('', 'Search crynet.to', False)
        kb.doModal()
        search = kb.getText()
        search=search.decode('utf-8').encode('iso-8859-1')
        data = {
            'cookieuser':'1',
            'vb_login_username': login,
            'vb_login_password': password,
            'do':'login',
            'submit':'anmelden',
            }
        login = 'http://crynet.to/forum/login.php?do=login'
        response = opener.open(login, urllib.urlencode(data)).read()
        main_url=opener.open('http://crynet.to/forum/content.php').read()
        token = re.search('var SECURITYTOKEN = "(.+?)"',main_url).group(1)

        data = {
            'do' : 'search',
            'do' : 'search',
            'lsawithword' : '1',
            'lsatype' : '0',
            'lsazone' : '',
            'lsasort' : 'lastpost',
            'lsasorttype' : 'DESC',
            'keyword' : search,
            'securitytoken' : token,
            's' : ''
            }
        url = 'http://crynet.to/forum/ajaxlivesearch.php?'
        suche = opener.open(url, urllib.urlencode( data)).read()
        match = re.compile('<span><a href=".*?" title="Stream">Stream</a></span>\r*\n*\r*\n*\s*<a href=".*?" title="Zum ersten ungelesenen Beitrag im Thema \'(.*?)\' gehen">.*?</a>.*?<a href="(.*?)" title=".*?">.*?<span class="highlight">.*?</span>.*?</a>').findall(suche)
        value=[]
        for name,url in match:
            ADDIR_NEW(html_parser.unescape(name.decode('iso-8859-1')).encode('utf-8'),html_parser.unescape(url),'',"MANAGE_SEARCH(url,name)",'','','','','','','folder','','','','')
        xbmc.executebuiltin("Container.SetViewMode(400)")

def MANAGE_SEARCH(url,name):
        content = url_opener(url)
        link = re.search('<meta http-equiv="refresh" content="0; URL=(.*?)">',content).group(1)
        col = None
        for i in collection:
            if i in name:
                LINKS_COLLECTIONS(link)
                col = i
        if col !=None:
            pass
        else:
            #~ print name
            VIDEOLINKS(link,str(name),'','','','','')

def LINKS_SERIE(name,url,iconimage,serien_name,season,tvdb_id):
        name = cleanFilename(str(name))
        data = url_opener(url)
        soup = BS(data.decode('iso-8859-1','ignore'))
        match=re.compile('<a href="(.*?)" target=".*?"><b><span style=".*?">(.*?)</span>').findall(data)
        nr=0
        y=1
        serie = False
        seasonfolder=''
        progress = xbmcgui.DialogProgress()
        progress.create('Folgeninfos werden geladen', 'This is a progress bar.')
        try:
            meta = metaget.get_seasons(serien_name.replace("HD:",""), tvdb_id, '1')[0]
            meta = metaget._get_season_posters(meta['tvdb_id'], '')
        except:
            pass
        for i, (link, title) in enumerate(match):
            try:
                try:
                    nr_vor = re.search('^(\d\d\.)\s*.*?$',title).group(1)
                    # print 'DENEME 1 : '+nr_vor
                    serie = True
                except:
                    nr_vor = re.search('^.*?(\d\d)$', title).group(1)
                    nr_vor = str(nr_vor+'.')
                    # print 'DENEME 2 : '+nr_vor
                    serie = True
                staffel_vor = re.search('.*\?mov=(\w+)(\d+)-.*',link)
            except:
                nr_vor = None
            staff = ''
            if 'Staffel' not in name:
                if staffel_vor != None and nr_vor != None:
                    nombre = re.search('^.*?(\d+)-(\d+)',link)
                    staff = str(nombre.group(1))
                if '1' == str(nombre.group(2)):
                    y=1
                    nr=nr+1
                    try:
                        for i in meta:
                            if i[2] == staff:
                                iconimage = i[0]
                                break
                    except:
                        pass
                    ADDIR_NEW('Staffel '+str(nombre.group(1)),url,url,"LINKS_SERIE(name,url,iconimage,serien_name,season,tvdb_id)",iconimage,'','','','','','season',serien_name.replace("HD:",""),staff,'',tvdb_id)
            else:
                if i < len(match):
                    percent = int((i/len(match))*100)
                    message =   str(i) + " von "+str(len(match))+" Folgen geladen"
                    progress.update(percent, message, "Dies passiert bei noch nie eingelesenen Folgen")
                if nr_vor != None and season in staffel_vor.group(1)+staffel_vor.group(2):
                    if '01.' == str(nr_vor):
                        nr=nr+1
                    if 'server' in link:
                        nr_vor = nr_vor.replace(".","")
                        nr_vor = int(nr_vor)
                        nr_vor = str(nr_vor)
                        #~ print 'oldu la',serien_name,season,nr_vor
                        ADDIR_NEW(html_parser.unescape(title.decode('iso-8859-1')).encode('utf8'),link,url,"play_premium_video(url,name,str(iconimage),tvdb_id,mpaa)",iconimage,'','','','','','episode',serien_name,season,nr_vor,tvdb_id)
        # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        # xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('MAIN') )

def VIDEOLINKS(url,name,thumbnail,imdb,trailer,serien_name,tvdb_id):
        data = url_opener(url)
        soup = BS(data.decode('iso-8859-1','ignore'))
        name1=None
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                if serien_name!="":
                    match=re.compile('<a href="(.*?)" target="Videoframe.*?">.*?HD(.*?)</.*?>').findall(data)
                    #~ print "Print 2 "+str(match)
                else:
                    match=re.compile('<a href="(.*?)" target="Videoframe.*?">').findall(data)
                if len(match)<1:
                    LINKS_SERIE(name,url,'',name,'','')
                plot=''
                mpaa=''
                link_name = ''
                tmp_url = ''
                for div in soup.findAll('div',  {"class": "quote_container"}):
                    plot = str(div(text=True)[1])
                try:
                    for div in soup.findAll('div',  {"class": "article cms_clear restore postcontainer"}):
                        mpaa = str(div(text=True))
                        mpaa= re.search("FSK:(.*?),",mpaa).group(1)
                except:
                        pass
                nr=0
                serie = False
                for i, e in enumerate(match):
                    if 'server' in e or 'Premium-Member' in e: ## Holt die Bezeichnung (HD Mobile)/(HD Plus) im Streamnamen ##
                        tmp_url = tmp_url + str(e)
                        if name1:
                            link_name = (name1[i/2].decode('iso-8859-1').encode('utf-8'))
                        else:
                            link_name = (name)
                    else:
                            pass
                    if link_name !='':
                        if 'Premium-Member' or 'Mobile' in e:
                            try:
                                nr_vor = re.search('(.*?\.) .*?',e[1]).group(1)
                            except:
                                nr_vor = None
                            if nr_vor != None:
                                if '01.'  == str(nr_vor):
                                    nr=nr+1
                                print "NUMMER 1"
                                ADDIR_NEW(html_parser.unescape(e[1].decode('iso-8859-1')).encode('utf8'),tmp_url,url,"play_premium_video(url,iconimage,name)",'','','','','','','season',serien_name,'','',tvdb_id)
                            else:
                                if (quality == '0' and 'Premium-Member' in e) or quality == '2':
                                    trailer= ''
                                    try:
                                        for object in soup.findAll('object', {"class": "restrain"},smartQuotesTo=None):
                                            code=re.search("http://www.youtube.com/v/(.*?)&fs=1", str(object.find('param')['value'])).group(1)
                                            url_tube='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)+"&hd=1"
                                            trailer= str(url_tube)
                                    except:
                                            pass
                                    print "NUMMER 2"
                                    if quality=='0':
                                        play_premium_video(e,link_name,str(thumbnail),imdb,mpaa)
                                    else:
                                        try:
                                            ADDIR_NEW(html_parser.unescape(link_name),e,url,"play_premium_video(url,name,str(iconimage),imdb,mpaa)",thumbnail,imdb,plot,mpaa,trailer,'','strm','','','','')
                                        except:
                                            ADDIR_NEW('Dieser'+link_name,e,url,"play_premium_video(url,name,str(iconimage),imdb,mpaa)",'','','','','','','strm','','','','')
                                elif (quality == '1' and 'Mobile' in e) or quality == '2':
                                    trailer= ''
                                    try:
                                        for object in soup.findAll('object', {"class": "restrain"},smartQuotesTo=None):
                                            code=re.search("http://www.youtube.com/v/(.*?)&fs=1", str(object.find('param')['value'])).group(1)
                                            url_tube='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)+"&hd=1"
                                            trailer= str(url_tube)
                                    except:
                                            pass
                                    print "NUMMER 2"
                                    if quality=='1':
                                        play_premium_video(e,link_name,str(thumbnail),imdb,mpaa)
                                    else:
                                        try:
                                            ADDIR_NEW(html_parser.unescape(link_name),e[0],url,"play_premium_video(url,name,str(iconimage),imdb,mpaa)",thumbnail,imdb,plot,mpaa,trailer,'','strm','','','','')
                                        except:
                                            ADDIR_NEW('Dieser'+link_name,e[0],url,"play_premium_video(url,name,str(iconimage),imdb,mpaa)",'','','','','','','strm','','','','')
                                else:
                                        pass
                            tmp_url = ''
                            link_name = ''
                    else:
                            pass
                    #~ tmp_url1=''
        except:
                raise
        """
        if 'Staffel' not in name:
            try:
                for object in soup.findAll('object', {"class": "restrain"},smartQuotesTo=None):
                    code=re.search("http://www.youtube.com/v/(.*?)&fs=1", str(object.find('param')['value'])).group(1)
                    url_tube='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)+"&hd=1"
                    enter_addDir('(Trailer) '+name,str(url_tube),'',"play_trailer(url,name,iconimage)",'','','','')
            except:
                    pass"play_premium_video(url,name,str(iconimage),imdb,mpaa)"
        """
        # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        # xbmc.executebuiltin("Container.SetViewMode(%d)" % 300 )

def play_trailer(url,name,thumbnail):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        enter_addLink(name,url,thumbnail,'','')
        listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
        xbmc.PlayList(1).add(url, listitem)
        xbmc.Player().play(pl)
def play_premium_video(url,name,thumbnail,imdb,mpaa):
        pl = xbmc.PlayList(1)
        pl.clear()
        try:
            dir_vid = url_opener(url)
            try:
                link = re.search('type="video/divx" src="(.*?)"',dir_vid).group(1)
                enter_addLink(name,link,thumbnail,imdb,'')
            except:
                link = re.search('<source src="(.?)" type="video/mp4" />',dir_vid).group(1)
                enter_addLink(name,link,thumbnail,imdb,'')
            listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
            listitem.setProperty('mimetype', 'video/x-msvideo')
            listitem.setProperty('IsPlayable', 'true')
            pl.add(link, listitem)
            xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
            xbmcPlayer.play(pl)
            xbmcgui.Window.close()
        except:
                pass

def play_free_video(url,name,thumbnail,imdb,mpaa):
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        try:
            video1 = url_opener(url)
            video_match1 = re.compile('src="(.*?)" type="video/mp4"').findall(video1)
            link = video_match1[0]
            # link = re.search('file=(http.*?)\.mp4.*?&', video1).group(1)
            enter_addLink(name,link,thumbnail,imdb,'')
            listitem = xbmcgui.ListItem(name,thumbnailImage=thumbnail)
            xbmc.PlayList(1).add(link, listitem)
            xbmc.Player().play(pl)
        except:
                pass

def LINKS_COLLECTIONS(url):
        data = url_opener(url)
        data = (data.decode('iso-8859-1').encode('utf-8')).replace('&amp;','&').replace('<font size="4">','').replace('<font size="3">  ','').replace('</font','')
        match=re.compile('<a href="(http://crynet.to/server/.*?php\?mov=.*?)" target=".*?">').findall(data)
        match1=re.compile('<*b*>*<font size=".*?">(.*?r*)</font><*/*b*>*<br /><div style="margin: 5px;">').findall(data)
        match2=re.compile('\r\n<.*?>\r*\n*(.*?r*)<*b*r*\s*/*>*\r*\n*<*b*r*\s*/*>*\r*\n*\s*<div style=".*?">').findall(data)
        jahr = re.compile('(?:Jahr:\s*\t*)?(\d\d\d\d),*\s*(?:<br\s/>|ca.)').findall(data)
        if match1:
            match_name = match1
        elif match2:
            match_name = match2
        soup = BS(data.decode('iso-8859-1','ignore'))
        value=[]
        for index, div in enumerate(soup.findAll('div',  {"class": "alt2"},smartQuotesTo=None)):
            try:
                img= div.find('img')['src']
                value.append(img)
            except:
                    pass
            if 'none;">Platzhalter</div>' in str(div) or 'Kein Film vorhanden!' in str(div):
                # del value[index]
                del match_name[index]
                #~ print match_name[index]
        match_video_HDPlus=[]
        match_video_Free=[]
        free = 0
        plus = 0
        progress = xbmcgui.DialogProgress()
        progress.create('Fortschritt', 'This is a progress bar.')
        try:
            status = re.search('Status:</span> &nbsp; <span style="color: #FF6600;">(.*?)</span>', data).group(1)
            if status == 'Premium Member':
                for index, i in enumerate(match):
                    #~ print ("Free: ",free)
                    #~ print ("Plus: ",plus)
                    if index < len(match):
                        percent = int((index/len(match))*100)
                        message =   str(index) + " von "+str(len(match))+" Filmen geladen"
                        progress.update(percent, message, "Dies passiert bei noch nie eingelesenen Filmen")
                    tmp_url = ''
                    if quality == '0' or quality == '2':
                        if 'Premium-Member' in i: ## DarkZone fix
                            if plus==free:
                                plus=plus+1
                            elif plus<free+1:
                                plus=plus+1
                            elif plus==free+1:
                                free=free+1
                                plus=plus+1
                            elif plus==free+2:
                                free=free+3
                                plus=plus+1
                            tmp_url = tmp_url + str(i)
                            trailer= ''
                            try:
                                for object in soup.findAll('object', {"class": "restrain"},smartQuotesTo=None):
                                    code=re.search("http://www.youtube.com/v/(.*?)&fs=1", str(object.find('param')['value'])).group(1)
                                    url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)+"&hd=1"
                                    trailer= str(url)
                            except:
                                    pass
                            try:
                                #~ print match_name[plus-1],tmp_url,url,value[plus-1]
                                ADDIR_NEW(match_name[plus-1]+' (HD Plus)',tmp_url,url,"play_premium_video(url,name,iconimage,imdb,mpaa)",value[plus-1],'','','',trailer,jahr[plus-1],'movie','collection','','','')
                            except:
                                ADDIR_NEW(match_name[plus-1]+' (HD Plus)',tmp_url,url,"play_premium_video(url,name,iconimage,imdb,mpaa)",value[plus-1],'','','',trailer,'','movie','collection','','','')

                    # if quality == '1' or quality == '2':
                        # if 'Mobile' in i:
                            # if free==plus:
                                # free=free+1
                            # elif free<plus+1:
                                # free=free+1
                            # elif free==plus+1:
                                # plus=plus+1
                                # free=free+1
                            # elif free==plus+2:
                                # plus=plus+3
                                # free=free+1
                            # tmp_url = tmp_url + str(i)
                            # match_video_Free.append(tmp_url)
                            # trailer= ''
                            # try:
                                # for object in soup.findAll('object', {"class": "restrain"},smartQuotesTo=None):
                                    # code=re.search("http://www.youtube.com/v/(.*?)&fs=1", str(object.find('param')['value'])).group(1)
                                    # url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)+"&hd=1"
                                    # trailer= str(url)
                            # except:
                                    # pass
                            # try:
                                # ADDIR_NEW(match_name[free-1]+' (HD Free)',tmp_url,url,"play_premium_video(url,name,iconimage,imdb,mpaa)",value[free-1],'','','',trailer,jahr[free-1],'movie','collection','','','')
                            # except:
                                # ADDIR_NEW(match_name[free-1]+' (HD Free)',tmp_url,url,"play_premium_video(url,name,iconimage,imdb,mpaa)",value[free-1],'','','',trailer,'','movie','collection','','','')
        except:
                pass
                
        # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        # xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('MAIN') )

def enter_addLink(name,url,iconimage,imdb,plot):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Rating": imdb, "Plot": plot, "MPAA": imdb} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def enter_addDir(name,url,url0,method,iconimage,imdb,plot,mpaa,trailer,year,status,serien_name,season,episode,tvdb):
        if status != 'folder':
            simplename = ''
            if 'movie' in status or 'tvshow' in status:
                if serien_name in 'collection':
                    simplename = name.replace("HD: ","").replace(" (HD Free)","").replace(" (HD Plus)","")
                else:
                    simplename = (urllib.unquote(cleanFilename(name)))#.replace("0xc3","")
                try:
                    meta = metaget.get_meta(str(status), str(simplename), (year.encode('utf-8')).replace("\*",""))
                except:
                    meta = {'backdrop_url': ''}
            elif status in 'episode':
                simplename = (urllib.unquote(cleanFilename(serien_name)))
                #~ print "name : "+simplename, "tvdb : "+tvdb, "season : "+str(season), "episode : "+str(episode)
                meta = metaget.get_episode_meta(str(simplename), tvdb, str(season), str(episode))
            else:
                meta = { "title": name,"rating": imdb, "plot": plot, "mpaa": mpaa, "trailer": trailer, "imdb_id": tvdb, "cover_url": "", "backdrop_url": "" }
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&url0="+urllib.quote_plus(url0)+"&method="+urllib.quote_plus(method)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&imdb="+str(imdb)+"&mpaa="+str(mpaa)+"&serien_name="+urllib.quote_plus(serien_name)+"&season="+urllib.quote_plus(season)+"&episode="+urllib.quote_plus(episode)+"&tvdb_id="+str(meta['imdb_id'])
            ok=True
            print simplename
            if not meta['cover_url']=='' and status=="movie": liz=xbmcgui.ListItem(simplename, iconImage="DefaultFolder.png", thumbnailImage=meta['cover_url'])
            if not meta['cover_url']=='' and status=="tvshow": liz=xbmcgui.ListItem(simplename, iconImage="DefaultFolder.png", thumbnailImage=meta['cover_url'])
            if not meta['cover_url']=='' and status=="episode": liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=meta['cover_url'])
            else: liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels=meta )
            liz.setInfo( type="Video", infoLabels={"overlay": 7, "watched": True} )
            menu=[]
            menu.append(('Film Information', 'XBMC.Action(Info)'))
            # menu.append(('Update Filminfo','XBMC.RunPlugin(%s?method=%s&name=%s&imdb_id=%s&year=%s&status=%s&url=%s)'% (sys.argv[0],urllib.quote_plus("Update_Meta(status, name, imdb_id, year, url)"), urllib.quote_plus(simplename),urllib.quote_plus(meta['imdb_id']), ((year.encode('utf-8')).replace("*","")), urllib.quote_plus(status), urllib.quote_plus(url))))
            if "play_premium_video" in method:
                menu.append(('Add To Library','XBMC.RunPlugin(%s?method=%s&name=%s&url=%s&iconimage=%s)'% (sys.argv[0],urllib.quote_plus("LIBRARY_MOVIE(name,url,iconimage)"), urllib.quote_plus(name),urllib.quote_plus(url), urllib.quote_plus(iconimage))))
            if status in 'tvshow':
                menu.append(('Serie in Library','XBMC.RunPlugin(%s?method=%s&name=%s&url=%s&iconimage=%s)'% (sys.argv[0],urllib.quote_plus("LIBRARY_SERIE(name,url,iconimage)"), urllib.quote_plus(name),urllib.quote_plus(url), urllib.quote_plus(iconimage))))
            liz.addContextMenuItems(items=menu, replaceItems=False)
            if not meta['backdrop_url'] == '' and status =="movie": liz.setProperty('fanart_image', "http://image.tmdb.org/t/p/original"+meta['backdrop_url'])
            elif not meta['backdrop_url'] == '' and status =="tvshow": liz.setProperty('fanart_image', meta['backdrop_url'])
            elif not meta['backdrop_url'] == '' and status =="episode": liz.setProperty('fanart_image', meta['backdrop_url'])
            else: liz.setProperty('fanart_image', '')
            if(status != "episode" or status != "strm" or serien_name!="strm"):
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
            else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&url0="+urllib.quote_plus(url0)+"&method="+urllib.quote_plus(method)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&imdb="+str(tvdb)+"&mpaa="+str(mpaa)+"&serien_name="+urllib.quote_plus(serien_name)+"&season="+urllib.quote_plus(season)+"&episode="+urllib.quote_plus(episode)+"&tvdb_id="+urllib.quote_plus(tvdb)
            ok=True
            liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
            liz.setInfo( type="Video", infoLabels={ "Title": name,"Rating": imdb, "Plot": plot, "MPAA": mpaa, "Trailer": trailer } )
            if(status != "episode" or status != "strm" or serien_name!="strm"):
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
            else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def enter_addDir_old(name,url,url0,method,iconimage,imdb,plot,mpaa,trailer,year,status,serien_name,season,episode,tvdb):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&url0="+urllib.quote_plus(url0)+"&method="+urllib.quote_plus(method)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&imdb="+str(imdb)+"&mpaa="+str(mpaa)+"&serien_name="+urllib.quote_plus(serien_name)+"&season="+urllib.quote_plus(season)+"&episode="+urllib.quote_plus(episode)+"&tvdb_id="
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name,"Rating": imdb, "Plot": plot, "MPAA": mpaa, "Trailer": trailer } )
        menu=[]
        if "play_premium_video" in method:
            menu.append(('Add To Library','XBMC.RunPlugin(%s?method=%s&name=%s&url=%s&iconimage=%s)'% (sys.argv[0],urllib.quote_plus("LIBRARY_MOVIE(name,url,iconimage)"), urllib.quote_plus(name),urllib.quote_plus(url), urllib.quote_plus(iconimage))))
        if status in 'tvshow':
            menu.append(('Serie in Library','XBMC.RunPlugin(%s?method=%s&name=%s&url=%s&iconimage=%s)'% (sys.argv[0],urllib.quote_plus("LIBRARY_SERIE(name,url,iconimage)"), urllib.quote_plus(name),urllib.quote_plus(url), urllib.quote_plus(iconimage))))
        liz.addContextMenuItems(items=menu, replaceItems=False)
        if(status == "episode" or status == "strm" or serien_name=="strm"):
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
          
def Update_Meta(status, name, imdb_id, year, url):
        dialog = xbmcgui.Dialog()
        new_imdb_id = dialog.input("IMDB ID eingeben bitte! ", type=xbmcgui.INPUT_ALPHANUM)
        neme = urllib.quote_plus(name)
        metaget.update_meta(status, name, url, '', tmdb_id='', new_imdb_id=new_imdb_id, new_tmdb_id='', year=year.replace("%2A", ""))
        metaget.update_meta(status, name, url, '', tmdb_id='', new_imdb_id=new_imdb_id, new_tmdb_id='', year=year.replace("%2A", ""))
        
def PLAY_VID(url,iconimage,name):
        dir_vid = url_opener(url)
        url = re.search('src="(.*?)"',dir_vid).group(1)
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        liz.setProperty("IsPlayable","true")
        strm = True
        if not strm:
                pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                pl.clear()
                pl.add(url, liz)
                xbmc.Player().play(pl)
                # return

        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def cleanFilename(filename):
    filename = filename.replace(" (HD Plus)","").replace(" (HD Free)","")
    try:
        nam1 = filename.split(": ")
        nam2 = nam1[1].split("[CR]")
        try:
            nam2[1]
            nam2 = nam1[1].split("[CR]")
        except:
            nam2 = nam1[1].split("[i]")
        #~ print nam2[0]
        filename = urllib.quote(nam2[0])
    except:
        try:
            nam1 = filename.split("HD ")
            filename = nam1[1]
        except:
            filename = filename
    try:
        filename=urllib.unquote_plus((filename.split("-"))[0])
    except:
        pass
    try:
        pat = re.search("(\(*\s*\d\d\d\d\s*\)*)",filename).group(1)
    except:
        pat = "xxxxxxxxxxx"
    try:
        for i in collection:
            filename = filename.replace(i,'')
    except:
        pass
    return (re.sub('[:\\/*?\<>|"]+', '', filename)).replace(pat,"").replace("(Serie)","").replace("div align=center","")


def LIBRARY_MOVIE(name,url,iconimage):#  cause method is empty in this one it will go back to first directory
        name = name.replace(' [I](HD Plus)[/I]','').replace(' [I](HD Plus)[/I]','')
        global library_path
        if library_path == 'false':
            dialog = xbmcgui.Dialog()
            library_path = dialog.browse(3, 'Movie Folder', 'files', '', False, False, "")
        strm=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&method=PLAY_VID(url,iconimage,name)"+"&name="+name+"&iconimage="+urllib.quote_plus(iconimage)
        foldername=os.path.join(library_path)
        filename = name + '.strm'
        file     = os.path.join(foldername,filename)

        a = open(file, "w")
        a.write(strm)
        a.close()

def LIBRARY_SERIE(name,url,iconimage):#  cause method is empty in this one it will go back to first directory
        #~ name = cleanFilename(str(name))
        data = url_opener(url)
        soup = BS(data.decode('iso-8859-1','ignore'))
        match=re.compile('<a href="(.*?)" target=".*?"><b><span style=".*?">(.*?)</span>').findall(data)
        global library_serie
        if library_serie == 'false':
            dialog = xbmcgui.Dialog()
            library_serie = dialog.browse(3, 'Serien Folder', 'files', '', False, False, "")
        foldermain=os.path.join(library_serie)
        foldername = os.path.join(foldermain, name)
        if not os.path.exists(foldername):
            os.mkdir(foldername)
        nr=0
        y=1
        serie = False
        seasonfolder=''
        for i, e in enumerate(match):
            try:
                try:
                    nr_vor = re.search('^(\d\d\.)\s*.*?$',e[1]).group(1)
                    # print 'DENEME 1 : '+nr_vor
                    serie = True
                except:
                    nr_vor = re.search('^.*?(\d\d)$', e[1]).group(1)
                    nr_vor = str(nr_vor+'.')
                    # print 'DENEME 2 : '+nr_vor
                    serie = True
                staffel_vor = re.search('.*\?mov=(\w+)(\d+)-.*',e[0])
            except:
                nr_vor = None
            if 'Staffel' not in name:
                if staffel_vor != None and nr_vor != None:
                    nombre = re.search('^.*?(\d+)-(\d+)',e[0])
                    # print "HIER :"+str(nombre.group(2))
                if '1' == str(nombre.group(2)):
                    # if '01.' == str(nr_vor):
                    y=1
                    nr=nr+1
                    seasonfolder = os.path.join(foldername, 'Staffel '+str(nombre.group(1)))
                    if not os.path.exists(seasonfolder):
                        os.mkdir(seasonfolder)
                        #enter_addDir('Staffel '+str(nombre.group(1)),url,url,"VIDEOLINKS(url,name,iconimage,imdb,trailer,serien_name,tvdb_id)",thumbnail,imdb,'','',trailer)
                etitle=e[1]
                if not e[1][0].isdigit():
                    etitle=str(y)+"."+e[1]
                    y=y+1
                #~ print "S"+str(nr)+"E"+etitle
                strm=sys.argv[0]+"?url="+urllib.quote_plus(e[0])+"&method=PLAY_VID(url,iconimage,name)"+"&name="+urllib.quote_plus(etitle)+"&iconimage="+urllib.quote_plus(iconimage)
                ename = cleanFilename("S"+str(nr)+"E"+etitle)
                filename = urllib.quote(ename) + '.strm'
                file = os.path.join(seasonfolder,filename)
                a = open(file, "w")
                a.write(strm)
                a.close()
        
def ADDIR_NEW(name,url,url0,method,iconimage,imdb,plot,mpaa,trailer,year,status,serien_name,season,episode,tvdb):
        if(infoscrap=="0"):
            enter_addDir(name,url,url0,method,iconimage,imdb,plot,mpaa,trailer,year,status,serien_name,season,episode,tvdb)
        else:
            enter_addDir_old(name,url,url0,method,iconimage,imdb,plot,mpaa,trailer,year,status,serien_name,season,episode,tvdb)
